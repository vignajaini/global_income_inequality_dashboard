import { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  AreaChart,
  Area,
  BarChart,
  Bar,
} from "recharts";

/* ----------------------------------------------------------
   TYPES
---------------------------------------------------------- */
type MobilityPoint = {
  year: number;
  igm: number; // Intergenerational mobility index
  upwardChance: number; // Chance of moving up by 2+ income deciles
  inequality: number; // Gini
};

type RegionOption = "Global" | "Asia" | "Europe" | "Africa" | "Latin America";

/* ----------------------------------------------------------
   MOCK DATA GENERATION
---------------------------------------------------------- */
function generateMockMobility(region: RegionOption): MobilityPoint[] {
  const base = {
    Global: 0.47,
    Asia: 0.42,
    Europe: 0.54,
    Africa: 0.36,
    "Latin America": 0.40,
  }[region];

  const startYear = 2000;
  return Array.from({ length: 24 }, (_, i) => {
    const year = startYear + i;

    // Smooth curve + random small variations
    const igm = +(base + Math.sin(i / 4) * 0.02 + i * 0.001).toFixed(3);

    // upward mobility ~ correlated with IGM
    const upwardChance = +((igm - 0.25) * 90 + Math.sin(i) * 2).toFixed(1);

    // inequality inversely related to mobility
    const inequality = +(45 - igm * 20 + Math.cos(i / 3) * 2).toFixed(1);

    return { year, igm, upwardChance, inequality };
  });
}

/* ----------------------------------------------------------
   UTILS: SMOOTHING FUNCTION
---------------------------------------------------------- */
function smoothSeries(series: MobilityPoint[], window = 3) {
  return series.map((p, idx) => {
    const start = Math.max(0, idx - window);
    const end = Math.min(series.length - 1, idx + window);
    const sliced = series.slice(start, end + 1);

    const avgIGM =
      sliced.reduce((sum, s) => sum + s.igm, 0) / sliced.length;

    return { ...p, igm: +avgIGM.toFixed(3) };
  });
}

/* ----------------------------------------------------------
   COMPONENT
---------------------------------------------------------- */
export default function MobilityTimeline() {
  const [region, setRegion] = useState<RegionOption>("Asia");
  const [enableSmooth, setEnableSmooth] = useState(false);

  const rawData = useMemo(() => generateMockMobility(region), [region]);

  const data = useMemo(
    () => (enableSmooth ? smoothSeries(rawData) : rawData),
    [rawData, enableSmooth]
  );

  const latest = data[data.length - 1];

  return (
    <div className="p-6">
      <h2 className="text-2xl font-semibold mb-4">Mobility Timeline</h2>

      {/* Controls */}
      <div className="flex flex-col md:flex-row gap-6 mb-6">
        <div className="bg-white p-4 rounded shadow w-full md:w-1/2">
          <h4 className="font-medium mb-2">Select Region</h4>
          <select
            value={region}
            onChange={(e) => setRegion(e.target.value as RegionOption)}
            className="p-2 border rounded w-full"
          >
            <option>Global</option>
            <option>Asia</option>
            <option>Europe</option>
            <option>Africa</option>
            <option>Latin America</option>
          </select>
        </div>

        <div className="bg-white p-4 rounded shadow w-full md:w-1/2 flex items-center justify-between">
          <div>
            <h4 className="font-medium mb-1">Trend Smoothing</h4>
            <p className="text-sm text-muted-foreground">
              Reduces volatility for clearer interpretation.
            </p>
          </div>
          <input
            type="checkbox"
            checked={enableSmooth}
            onChange={(e) => setEnableSmooth(e.target.checked)}
            className="w-5 h-5"
          />
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-5 rounded shadow">
          <div className="text-sm text-muted-foreground">Intergen. Mobility</div>
          <div className="text-2xl font-bold">{latest.igm}</div>
        </div>

        <div className="bg-white p-5 rounded shadow">
          <div className="text-sm text-muted-foreground">Upward Mobility Chance</div>
          <div className="text-2xl font-bold">{latest.upwardChance}%</div>
        </div>

        <div className="bg-white p-5 rounded shadow">
          <div className="text-sm text-muted-foreground">Inequality (Gini)</div>
          <div className="text-2xl font-bold">{latest.inequality}</div>
        </div>
      </div>

      {/* Timeline Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* IGM timeline */}
        <div className="bg-white p-4 rounded shadow">
          <h4 className="font-semibold mb-3">Intergenerational Mobility Over Time</h4>
          <div style={{ height: 350 }}>
            <ResponsiveContainer>
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis domain={["dataMin - 0.02", "dataMax + 0.02"]} />
                <Tooltip />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="igm"
                  stroke="#2563eb"
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Upward Mobility chance */}
        <div className="bg-white p-4 rounded shadow">
          <h4 className="font-semibold mb-3">Chance of Upward Income Mobility (%)</h4>
          <div style={{ height: 350 }}>
            <ResponsiveContainer>
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorUp" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.1}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis />
                <Tooltip />
                <Area
                  type="monotone"
                  dataKey="upwardChance"
                  stroke="#047857"
                  fill="url(#colorUp)"
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Mobility vs Inequality */}
        <div className="bg-white p-4 rounded shadow col-span-1 lg:col-span-2">
          <h4 className="font-semibold mb-3">
            Mobility vs Inequality — Inverse Relationship
          </h4>
          <div style={{ height: 350 }}>
            <ResponsiveContainer>
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis yAxisId="left" orientation="left" />
                <YAxis yAxisId="right" orientation="right" />
                <Tooltip />
                <Legend />

                <Line
                  yAxisId="left"
                  type="monotone"
                  dataKey="igm"
                  stroke="#2563eb"
                  dot={false}
                  strokeWidth={2}
                  name="Mobility Index"
                />

                <Line
                  yAxisId="right"
                  type="monotone"
                  dataKey="inequality"
                  stroke="#dc2626"
                  dot={false}
                  strokeWidth={2}
                  name="Gini (Inequality)"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Notes */}
      <div className="bg-white p-4 rounded shadow mt-8">
        <h4 className="font-semibold mb-2">Interpretation Guide</h4>
        <ul className="list-disc pl-5 text-sm text-muted-foreground">
          <li>Higher intergenerational mobility means children are less “trapped” in the same income level as their parents.</li>
          <li>Regions with lower inequality generally show higher mobility over long periods.</li>
          <li>
            Use smoothing to reveal long-term structural change rather than yearly noise.
          </li>
          <li>
            Combine this with the “Policy Impact Simulator” to observe policy–mobility interactions.
          </li>
        </ul>
      </div>
    </div>
  );
}
