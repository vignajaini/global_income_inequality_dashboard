import React, { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
} from "recharts";

/**
 * MultiTimeline.tsx
 * Compare multiple indicators across two countries on a single timeline.
 */

const COUNTRY_PAIRS = [
  { id: "in_cn", a: "India", b: "China", label: "India vs China" },
  { id: "us_uk", a: "United States", b: "United Kingdom", label: "US vs UK" },
  { id: "br_sa", a: "Brazil", b: "South Africa", label: "Brazil vs South Africa" },
];

const INDICATORS = [
  { id: "gini", label: "Gini Index", colorA: "#1f77b4", colorB: "#aec7e8" },
  { id: "palma", label: "Palma Ratio", colorA: "#ff7f0e", colorB: "#ffbb78" },
  { id: "gdp", label: "GDP per Capita", colorA: "#2ca02c", colorB: "#98df8a" },
];

// Generate dummy data
function makeTimelineData(pairId: string) {
  const years = Array.from({ length: 13 }, (_, i) => 2010 + i);

  return years.map((year, idx) => ({
    year,
    // baseline shifts so all lines look unique
    giniA: 30 + idx * 0.4 + (pairId === "in_cn" ? 3 : 0),
    giniB: 28 + idx * 0.5 + (pairId === "in_cn" ? 2 : 1),

    palmaA: 1 + Math.sin(idx / 2) * 0.2,
    palmaB: 0.9 + Math.cos(idx / 3) * 0.15,

    gdpA: 2000 + idx * 200 + (pairId === "us_uk" ? 500 : 0),
    gdpB: 1800 + idx * 180 + (pairId === "us_uk" ? 450 : 0),
  }));
}

export default function MultiTimeline() {
  const [pair, setPair] = useState(COUNTRY_PAIRS[0].id);

  const [active, setActive] = useState({
    gini: true,
    palma: true,
    gdp: true,
  });

  // Memo dataset
  const data = useMemo(() => makeTimelineData(pair), [pair]);

  const pairInfo = COUNTRY_PAIRS.find((p) => p.id === pair)!;

  // count how many indicators selected
  const selectedIndicators = Object.values(active).filter(Boolean).length;

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-2xl font-semibold mb-4">
        Multi-Indicator Timeline
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_300px] gap-6">
        {/* LEFT PANEL */}
        <div className="bg-white p-5 rounded-lg shadow">
          <h2 className="text-lg font-medium mb-3">
            {pairInfo.a} vs {pairInfo.b}
          </h2>

          <p className="text-sm text-muted-foreground mb-4">
            Select indicators on the right to show/hide lines.
          </p>

          <div style={{ height: 380 }} className="bg-gray-50 rounded p-3">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis />
                <Tooltip />
                <Legend />

                {/* Conditional line rendering */}
                {active.gini && (
                  <>
                    <Line
                      dataKey="giniA"
                      name={`${pairInfo.a} – Gini`}
                      stroke="#1f77b4"
                      strokeWidth={2}
                      dot={false}
                    />
                    <Line
                      dataKey="giniB"
                      name={`${pairInfo.b} – Gini`}
                      stroke="#aec7e8"
                      strokeWidth={2}
                      dot={false}
                    />
                  </>
                )}

                {active.palma && (
                  <>
                    <Line
                      dataKey="palmaA"
                      name={`${pairInfo.a} – Palma`}
                      stroke="#ff7f0e"
                      strokeWidth={2}
                      dot={false}
                    />
                    <Line
                      dataKey="palmaB"
                      name={`${pairInfo.b} – Palma`}
                      stroke="#ffbb78"
                      strokeWidth={2}
                      dot={false}
                    />
                  </>
                )}

                {active.gdp && (
                  <>
                    <Line
                      dataKey="gdpA"
                      name={`${pairInfo.a} – GDP`}
                      stroke="#2ca02c"
                      strokeWidth={2}
                      dot={false}
                    />
                    <Line
                      dataKey="gdpB"
                      name={`${pairInfo.b} – GDP`}
                      stroke="#98df8a"
                      strokeWidth={2}
                      dot={false}
                    />
                  </>
                )}
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* If zero selected */}
          {selectedIndicators === 0 && (
            <p className="text-center text-sm text-muted-foreground mt-4">
              Select at least one indicator to view the chart.
            </p>
          )}
        </div>

        {/* RIGHT SIDEBAR */}
        <aside className="bg-white p-5 rounded-lg shadow space-y-4">
          <div>
            <label className="block text-sm mb-1 font-medium">Select Countries</label>
            <select
              value={pair}
              onChange={(e) => setPair(e.target.value)}
              className="w-full border rounded px-3 py-2"
            >
              {COUNTRY_PAIRS.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.label}
                </option>
              ))}
            </select>
          </div>

          <div className="pt-3 border-t">
            <h3 className="font-medium text-sm mb-2">Indicators</h3>

            <div className="space-y-2">
              {INDICATORS.map((ind) => (
                <label key={ind.id} className="flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={active[ind.id as keyof typeof active]}
                    onChange={(e) =>
                      setActive({ ...active, [ind.id]: e.target.checked })
                    }
                  />
                  {ind.label}
                </label>
              ))}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
