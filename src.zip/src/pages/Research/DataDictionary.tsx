import { useState } from "react";

export default function DataDictionary() {
  const [search, setSearch] = useState("");

  const terms = [
    { term: "Gini Index", meaning: "A measure of income inequality (0 = equal, 1 = unequal)." },
    { term: "Palma Ratio", meaning: "Ratio of richest 10% income to poorest 40%." },
    { term: "GDP per Capita", meaning: "Economic output per person." },
    { term: "Mobility Index", meaning: "How easily people move between income classes." },
    { term: "Poverty Line", meaning: "Minimum level of income deemed adequate." },
  ];

  const filtered = terms.filter((t) =>
    t.term.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div style={{ padding: "30px" }}>
      <h2>Data Dictionary</h2>
      <p style={{ marginBottom: "20px" }}>
        A reference guide for variables, indicators, and dataset terminology.
      </p>

      <input
        type="text"
        placeholder="Search terms..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={{
          width: "100%",
          padding: "12px",
          borderRadius: "10px",
          border: "1px solid #ccc",
          marginBottom: "25px",
        }}
      />

      <div
        style={{
          background: "#fff",
          padding: "20px",
          borderRadius: "14px",
          boxShadow: "0 0 12px rgba(0,0,0,0.08)",
        }}
      >
        {filtered.length === 0 && <p>No matching terms found.</p>}

        <ul style={{ listStyle: "none", padding: 0 }}>
          {filtered.map((item, index) => (
            <li
              key={index}
              style={{
                marginBottom: "20px",
                paddingBottom: "10px",
                borderBottom: "1px solid #eee",
              }}
            >
              <strong style={{ fontSize: "16px" }}>{item.term}</strong>
              <p style={{ color: "#555", marginTop: "5px" }}>{item.meaning}</p>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
