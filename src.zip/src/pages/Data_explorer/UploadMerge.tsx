import React, { useState } from "react";
import Papa from "papaparse";

/**
 * UploadMerge.tsx
 * Advanced CSV upload + merge UI and client-side merging logic.
 *
 * Drop into: src/pages/Data_explorer/UploadMerge.tsx
 */

type ParsedTable = {
  headers: string[];
  rows: Record<string, string | null>[]; // each row is a map header -> value (string)
};

function parseCSVFile(file: File): Promise<ParsedTable> {
  return new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      dynamicTyping: false,
      complete: (results) => {
        const data = results.data as Record<string, string>[];
        const headers = results.meta.fields ?? [];
        // normalize rows: ensure every header exists
        const rows = data.map((r) => {
          const out: Record<string, string | null> = {};
          for (const h of headers) {
            out[h] = r[h] ?? "";
          }
          return out;
        });
        resolve({ headers, rows });
      },
      error: (err) => reject(err),
    });
  });
}

/** Merge implementations: inner, left, right, outer */
function mergeTables(
  left: ParsedTable,
  right: ParsedTable,
  leftKey: string,
  rightKey: string,
  joinType: "inner" | "left" | "right" | "outer"
): ParsedTable {
  // Build maps of key -> array(rows)
  const leftMap = new Map<string, Record<string, string | null>[]>();
  const rightMap = new Map<string, Record<string, string | null>[]>();

  for (const r of left.rows) {
    const k = (r[leftKey] ?? "").toString();
    if (!leftMap.has(k)) leftMap.set(k, []);
    leftMap.get(k)!.push(r);
  }
  for (const r of right.rows) {
    const k = (r[rightKey] ?? "").toString();
    if (!rightMap.has(k)) rightMap.set(k, []);
    rightMap.get(k)!.push(r);
  }

  // Build merged headers
  const mergedHeaders: string[] = [];
  // start with left headers
  for (const h of left.headers) mergedHeaders.push(h);

  // add right headers; if conflict (and not join key), suffix with _r
  for (const h of right.headers) {
    if (h === rightKey) {
      // if join key exists in left headers, skip adding duplicate; otherwise add using rightKey name
      if (!left.headers.includes(leftKey)) mergedHeaders.push(h);
      continue;
    }
    if (left.headers.includes(h)) {
      mergedHeaders.push(`${h}_r`);
    } else {
      mergedHeaders.push(h);
    }
  }

  const resultRows: Record<string, string | null>[] = [];
  const seenKeys = new Set<string>();

  const addCombined = (l?: Record<string, string | null>, r?: Record<string, string | null>) => {
    const out: Record<string, string | null> = {};
    // fill left headers
    for (const h of left.headers) {
      out[h] = l ? (l[h] ?? "") : null;
    }
    // fill right headers
    for (const h of right.headers) {
      if (h === rightKey) {
        // if left had join key under leftKey, use the left value; else use right's key
        if (left.headers.includes(leftKey)) {
          out[leftKey] = l ? (l[leftKey] ?? "") : (r ? (r[rightKey] ?? "") : null);
        } else {
          out[h] = r ? (r[h] ?? "") : null;
        }
        continue;
      }

      if (left.headers.includes(h)) {
        // conflict -> store under `${h}_r`
        out[`${h}_r`] = r ? (r[h] ?? "") : null;
      } else {
        out[h] = r ? (r[h] ?? "") : null;
      }
    }
    resultRows.push(out);
  };

  // Using sets of keys depending on join type
  const leftKeys = Array.from(leftMap.keys());
  const rightKeys = Array.from(rightMap.keys());
  const allKeys = new Set<string>([...leftKeys, ...rightKeys]);

  if (joinType === "inner") {
    for (const k of allKeys) {
      if (leftMap.has(k) && rightMap.has(k)) {
        for (const l of leftMap.get(k)!) {
          for (const r of rightMap.get(k)!) {
            addCombined(l, r);
          }
        }
      }
    }
  } else if (joinType === "left") {
    for (const k of leftKeys) {
      if (rightMap.has(k)) {
        for (const l of leftMap.get(k)!) {
          for (const r of rightMap.get(k)!) {
            addCombined(l, r);
          }
        }
      } else {
        for (const l of leftMap.get(k)!) {
          addCombined(l, undefined);
        }
      }
    }
  } else if (joinType === "right") {
    for (const k of rightKeys) {
      if (leftMap.has(k)) {
        for (const l of leftMap.get(k)!) {
          for (const r of rightMap.get(k)!) {
            addCombined(l, r);
          }
        }
      } else {
        for (const r of rightMap.get(k)!) {
          addCombined(undefined, r);
        }
      }
    }
  } else if (joinType === "outer") {
    for (const k of allKeys) {
      const leftRows = leftMap.get(k) ?? [undefined];
      const rightRows = rightMap.get(k) ?? [undefined];

      if (leftRows[0] === undefined && rightRows[0] !== undefined) {
        // only right rows
        for (const r of rightRows) addCombined(undefined, r);
        continue;
      }
      if (rightRows[0] === undefined && leftRows[0] !== undefined) {
        // only left rows
        for (const l of leftRows) addCombined(l, undefined);
        continue;
      }

      // both present or both undefined (rare)
      for (const l of leftRows) {
        for (const r of rightRows) {
          addCombined(l, r);
        }
      }
    }
  }

  return { headers: mergedHeaders, rows: resultRows };
}

export default function UploadMerge() {
  const [leftFileName, setLeftFileName] = useState<string | null>(null);
  const [rightFileName, setRightFileName] = useState<string | null>(null);
  const [leftTable, setLeftTable] = useState<ParsedTable | null>(null);
  const [rightTable, setRightTable] = useState<ParsedTable | null>(null);

  const [leftKey, setLeftKey] = useState<string>("");
  const [rightKey, setRightKey] = useState<string>("");
  const [joinType, setJoinType] = useState<"inner" | "left" | "right" | "outer">("inner");

  const [merged, setMerged] = useState<ParsedTable | null>(null);
  const [loading, setLoading] = useState(false);
  const [previewSize] = useState(200);

  // handle file input
  const handleLeftFile = async (f?: File) => {
    if (!f) return;
    setLeftFileName(f.name);
    setLoading(true);
    try {
      const parsed = await parseCSVFile(f);
      setLeftTable(parsed);
      // default join key to first header if none chosen
      if (!leftKey && parsed.headers.length > 0) setLeftKey(parsed.headers[0]);
    } catch (err) {
      alert("Failed to parse left file: " + (err as any).message);
    } finally {
      setLoading(false);
    }
  };

  const handleRightFile = async (f?: File) => {
    if (!f) return;
    setRightFileName(f.name);
    setLoading(true);
    try {
      const parsed = await parseCSVFile(f);
      setRightTable(parsed);
      if (!rightKey && parsed.headers.length > 0) setRightKey(parsed.headers[0]);
    } catch (err) {
      alert("Failed to parse right file: " + (err as any).message);
    } finally {
      setLoading(false);
    }
  };

  const handleMerge = () => {
    if (!leftTable || !rightTable) {
      alert("Upload both left and right CSV files first.");
      return;
    }
    if (!leftKey || !rightKey) {
      alert("Select join keys from both files.");
      return;
    }
    setLoading(true);
    try {
      const out = mergeTables(leftTable, rightTable, leftKey, rightKey, joinType);
      setMerged(out);
      // scroll into view maybe (if you want)
      setTimeout(() => {
        const el = document.getElementById("merged-preview");
        if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
      }, 120);
    } catch (err) {
      alert("Merge failed: " + (err as any).message);
    } finally {
      setLoading(false);
    }
  };

  const downloadMerged = () => {
    if (!merged) return;
    const csv = Papa.unparse({
      fields: merged.headers,
      data: merged.rows.map((r) => merged.headers.map((h) => r[h] ?? "")),
    });
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `merged_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // small helper to show a table preview
  const TablePreview: React.FC<{ table: ParsedTable | null; limit?: number }> = ({ table, limit = 10 }) => {
    if (!table) return <div className="text-sm text-muted-foreground">No data</div>;
    const rows = table.rows.slice(0, limit);
    return (
      <div className="overflow-auto border rounded">
        <table className="w-full text-sm">
          <thead className="bg-gray-50">
            <tr>
              {table.headers.map((h) => (
                <th key={h} className="px-2 py-1 text-left border-r last:border-r-0">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                {table.headers.map((h) => (
                  <td key={h} className="px-2 py-1 border-r last:border-r-0">{r[h] ?? ""}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <div className="p-6 max-w-screen-5xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Upload & Merge Data</h1>
      <p className="text-sm text-muted-foreground">
        Upload two CSV files and merge them client-side. Supports inner/left/right/full joins and simple column conflict resolution.
      </p>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* LEFT FILE */}
        <div className="bg-white p-4 rounded shadow">
          <h3 className="font-semibold mb-2">Left file (Primary)</h3>
          <div className="flex gap-2 items-center">
            <input
              id="left-file"
              type="file"
              accept=".csv,text/csv"
              onChange={(e) => handleLeftFile(e.target.files?.[0])}
            />
            {leftFileName && <span className="text-sm text-muted-foreground">{leftFileName}</span>}
          </div>

          <div className="mt-4">
            <p className="text-sm font-medium">Preview</p>
            <TablePreview table={leftTable} limit={5} />
          </div>
        </div>

        {/* RIGHT FILE */}
        <div className="bg-white p-4 rounded shadow">
          <h3 className="font-semibold mb-2">Right file (Secondary)</h3>
          <div className="flex gap-2 items-center">
            <input
              id="right-file"
              type="file"
              accept=".csv,text/csv"
              onChange={(e) => handleRightFile(e.target.files?.[0])}
            />
            {rightFileName && <span className="text-sm text-muted-foreground">{rightFileName}</span>}
          </div>

          <div className="mt-4">
            <p className="text-sm font-medium">Preview</p>
            <TablePreview table={rightTable} limit={5} />
          </div>
        </div>
      </div>

      {/* Mapping & Options */}
      <div className="bg-white p-4 rounded shadow grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-sm font-medium">Left Join Key</label>
          <select
            value={leftKey}
            onChange={(e) => setLeftKey(e.target.value)}
            className="mt-1 block w-full border rounded p-2"
            disabled={!leftTable}
          >
            <option value="">Select left key</option>
            {leftTable?.headers.map((h) => <option key={h} value={h}>{h}</option>)}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium">Right Join Key</label>
          <select
            value={rightKey}
            onChange={(e) => setRightKey(e.target.value)}
            className="mt-1 block w-full border rounded p-2"
            disabled={!rightTable}
          >
            <option value="">Select right key</option>
            {rightTable?.headers.map((h) => <option key={h} value={h}>{h}</option>)}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium">Join Type</label>
          <select
            value={joinType}
            onChange={(e) => setJoinType(e.target.value as any)}
            className="mt-1 block w-full border rounded p-2"
          >
            <option value="inner">Inner Join</option>
            <option value="left">Left Join (preserve left)</option>
            <option value="right">Right Join (preserve right)</option>
            <option value="outer">Full Outer Join</option>
          </select>
        </div>

        <div className="md:col-span-3 text-right">
          <button
            onClick={handleMerge}
            className="px-4 py-2 bg-blue-600 text-white rounded shadow"
            disabled={loading}
          >
            {loading ? "Processing..." : "Merge"}
          </button>
        </div>
      </div>

      {/* Merged preview + actions */}
      <div id="merged-preview" className="bg-white p-4 rounded shadow space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Merged Preview</h3>
          <div className="flex gap-2">
            {merged && (
              <>
                <button
                  onClick={() => downloadMerged()}
                  className="px-3 py-1 bg-green-600 text-white rounded"
                >
                  Download CSV
                </button>
                <button
                  onClick={() => {
                    navigator.clipboard?.writeText(JSON.stringify(merged.rows.slice(0, 50)));
                    alert("Sample JSON copied to clipboard (first 50 rows)");
                  }}
                  className="px-3 py-1 bg-gray-200 rounded"
                >
                  Copy JSON (sample)
                </button>
              </>
            )}
          </div>
        </div>

        {merged ? (
          <>
            <p className="text-sm text-muted-foreground">
              Showing up to {previewSize} rows. Merged rows: {merged.rows.length}
            </p>
            <div className="overflow-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    {merged.headers.map((h) => (
                      <th key={h} className="px-2 py-1 text-left border-r last:border-r-0">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {merged.rows.slice(0, previewSize).map((r, i) => (
                    <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                      {merged.headers.map((h) => (
                        <td key={h} className="px-2 py-1 border-r last:border-r-0">{r[h] ?? ""}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        ) : (
          <p className="text-sm text-muted-foreground">Merged result will appear here after you click Merge.</p>
        )}
      </div>
    </div>
  );
}
