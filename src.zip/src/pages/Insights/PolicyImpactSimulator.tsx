import React, { useState, useMemo } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from "recharts";

/* --------------------------------------------
   Types
----------------------------------------------*/
type Country = "IND" | "USA" | "BRA" | "CHN";

interface PolicyInputs {
  educationBoost: number; // 0–1
  taxProgressivity: number; // 0–1
  cashTransfers: number; // 0–1
  wageSubsidy: number; // 0–1
  years: number;        // projection years
}

/* --------------------------------------------
   Baseline country parameters – mock model
----------------------------------------------*/
const BASE_COUNTRY_STATS = {
  IND: { gdp: 3.5, inequality: 0.41, opportunity: 52, poverty: 18 },
  USA: { gdp: 2.1, inequality: 0.39, opportunity: 68, poverty: 11 },
  CHN: { gdp: 4.8, inequality: 0.38, opportunity: 61, poverty: 7 },
  BRA: { gdp: 2.2, inequality: 0.51, opportunity: 48, poverty: 21 },
};

/* --------------------------------------------
   Simulation model
   (Replace with backend / API later)
----------------------------------------------*/
function simulatePolicyImpact(country: Country, policy: PolicyInputs) {
  const base = BASE_COUNTRY_STATS[country];

  const { educationBoost, taxProgressivity, cashTransfers, wageSubsidy, years } = policy;

  // Weighting factors (heuristic model)
  const w = {
    edu: 0.35,
    tax: 0.25,
    cash: 0.2,
    wage: 0.2,
  };

  // Time series outputs
  const timeline = [];
  let gdp = base.gdp;
  let inequality = base.inequality;
  let opportunity = base.opportunity;
  let poverty = base.poverty;

  for (let year = 1; year <= years; year++) {
    const t = year / years;

    const eduEffect = educationBoost * w.edu * Math.log(1 + t);
    const taxEffect = taxProgressivity * w.tax * t * 0.8;
    const cashEffect = cashTransfers * w.cash * (1 - Math.exp(-t * 2));
    const wageEffect = wageSubsidy * w.wage * Math.log(1 + t * 1.2);

    // --- GDP growth impact ---
    gdp = gdp + eduEffect * 0.6 + wageEffect * 0.4;

    // --- Inequality improvement ---
    inequality =
      inequality -
      taxEffect * 0.02 -
      cashEffect * 0.015 -
      eduEffect * 0.01 +
      Math.sin(t * 2) * 0.001;

    // --- Opportunity score ---
    opportunity =
      opportunity +
      eduEffect * 9 +
      cashEffect * 6 +
      wageEffect * 8 -
      taxEffect * 2;

    // --- Poverty reduction ---
    poverty =
      poverty -
      cashEffect * 1.8 -
      wageEffect * 1.1 -
      eduEffect * 0.8 +
      Math.random() * 0.2;

    timeline.push({
      year,
      gdp: +gdp.toFixed(2),
      inequality: +inequality.toFixed(3),
      opportunity: +opportunity.toFixed(1),
      poverty: +poverty.toFixed(1),
    });
  }

  return timeline;
}

/* --------------------------------------------
   Component
----------------------------------------------*/
export default function PolicyImpactSimulator(): JSX.Element {
  const [country, setCountry] = useState<Country>("IND");

  const [years, setYears] = useState(15);
  const [educationBoost, setEducationBoost] = useState(0.4);
  const [taxProgressivity, setTaxProgressivity] = useState(0.25);
  const [cashTransfers, setCashTransfers] = useState(0.2);
  const [wageSubsidy, setWageSubsidy] = useState(0.3);

  const policy: PolicyInputs = {
    educationBoost,
    taxProgressivity,
    cashTransfers,
    wageSubsidy,
    years,
  };

  const results = useMemo(() => simulatePolicyImpact(country, policy), [country, policy]);

  const last = results[results.length - 1];
  const base = BASE_COUNTRY_STATS[country];

  const diff = {
    gdp: +(last.gdp - base.gdp).toFixed(2),
    inequality: +(base.inequality - last.inequality).toFixed(3),
    opportunity: +(last.opportunity - base.opportunity).toFixed(1),
    poverty: +(base.poverty - last.poverty).toFixed(1),
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-4">Policy Impact Simulator — Advanced</h1>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-6">
        {/* LEFT PANEL — POLICY CONTROLS */}
        <div className="bg-white p-4 rounded shadow space-y-4">
          <h3 className="font-semibold text-lg">Policy Controls</h3>

          <label className="text-sm">Country</label>
          <select
            className="w-full border p-2 rounded"
            value={country}
            onChange={(e) => setCountry(e.target.value as Country)}
          >
            <option value="IND">India</option>
            <option value="USA">USA</option>
            <option value="CHN">China</option>
            <option value="BRA">Brazil</option>
          </select>

          <label className="text-sm">Years to simulate</label>
          <select
            className="w-full border p-2 rounded"
            value={years}
            onChange={(e) => setYears(Number(e.target.value))}
          >
            <option value={10}>10 Years</option>
            <option value={15}>15 Years</option>
            <option value={20}>20 Years</option>
          </select>

          {/* POLICY SLIDERS */}
          <div>
            <label className="text-sm">Education Boost</label>
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={educationBoost}
              onChange={(e) => setEducationBoost(parseFloat(e.target.value))}
              className="w-full"
            />
            <div className="text-xs">{Math.round(educationBoost * 100)}%</div>
          </div>

          <div>
            <label className="text-sm">Tax Progressivity</label>
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={taxProgressivity}
              onChange={(e) => setTaxProgressivity(parseFloat(e.target.value))}
              className="w-full"
            />
            <div className="text-xs">{Math.round(taxProgressivity * 100)}%</div>
          </div>

          <div>
            <label className="text-sm">Cash Transfers</label>
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={cashTransfers}
              onChange={(e) => setCashTransfers(parseFloat(e.target.value))}
              className="w-full"
            />
            <div className="text-xs">{Math.round(cashTransfers * 100)}%</div>
          </div>

          <div>
            <label className="text-sm">Wage Subsidy</label>
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={wageSubsidy}
              onChange={(e) => setWageSubsidy(parseFloat(e.target.value))}
              className="w-full"
            />
            <div className="text-xs">{Math.round(wageSubsidy * 100)}%</div>
          </div>
        </div>

        {/* RIGHT PANEL — METRICS */}
        <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* GDP */}
          <div className="bg-white p-4 rounded shadow">
            <div className="text-sm text-gray-500">GDP Growth</div>
            <div className="text-2xl font-bold">{last.gdp}%</div>
            <div className="text-xs text-green-600">+{diff.gdp} pts</div>
          </div>

          {/* Inequality */}
          <div className="bg-white p-4 rounded shadow">
            <div className="text-sm text-gray-500">Inequality (Gini)</div>
            <div className="text-2xl font-bold">{last.inequality}</div>
            <div className="text-xs text-green-600">-{diff.inequality}</div>
          </div>

          {/* Opportunity */}
          <div className="bg-white p-4 rounded shadow">
            <div className="text-sm text-gray-500">Opportunity Index</div>
            <div className="text-2xl font-bold">{last.opportunity}</div>
            <div className="text-xs text-green-600">+{diff.opportunity}</div>
          </div>

          {/* Poverty */}
          <div className="bg-white p-4 rounded shadow">
            <div className="text-sm text-gray-500">Poverty (%)</div>
            <div className="text-2xl font-bold">{last.poverty}%</div>
            <div className="text-xs text-green-600">-{diff.poverty}</div>
          </div>
        </div>
      </div>

      {/* CHARTS SECTION */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Opportunity Over Time */}
        <div className="bg-white p-4 rounded shadow">
          <h3 className="font-semibold mb-3">Opportunity Index Over Time</h3>
          <div style={{ height: 300 }}>
            <ResponsiveContainer>
              <LineChart data={results}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="opportunity" stroke="#2563eb" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Inequality + Poverty */}
        <div className="bg-white p-4 rounded shadow">
          <h3 className="font-semibold mb-3">Inequality & Poverty Trend</h3>
          <div style={{ height: 300 }}>
            <ResponsiveContainer>
              <LineChart data={results}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="inequality" stroke="#dc2626" strokeWidth={2} />
                <Line type="monotone" dataKey="poverty" stroke="#16a34a" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* GDP Bar Chart */}
        <div className="bg-white p-4 rounded shadow lg:col-span-2">
          <h3 className="font-semibold mb-3">GDP Projection</h3>
          <div style={{ height: 300 }}>
            <ResponsiveContainer>
              <BarChart data={results}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="gdp" fill="#0ea5e9" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Interpretation */}
      <div className="mt-6 bg-white p-4 rounded shadow">
        <h4 className="font-semibold">Interpretation</h4>
        <ul className="list-disc pl-5 text-sm text-gray-600 mt-2">
          <li>Education & wage subsidies raise long-term productivity and opportunity.</li>
          <li>Progressive taxes reduce inequality gradually while protecting growth.</li>
          <li>Cash transfers lower poverty significantly in short term.</li>
          <li>This model is heuristic — connect to backend micro-simulation for real accuracy.</li>
        </ul>
      </div>
    </div>
  );
}
