import { useState } from "react";

export default function Datasets() {
  const datasets = [
    {
      name: "Global Income Distribution Dataset",
      description:
        "Includes global income share, GDP per capita, and income inequality indicators from 1990–2023.",
      size: "8.3 MB",
      format: "CSV",
      link: "#", // replace with actual file
    },
    {
      name: "Country-Level Gini Index Dataset",
      description:
        "Gini coefficients across 180+ countries with annual updates and demographic breakdowns.",
      size: "5.1 MB",
      format: "CSV / Excel",
      link: "#",
    },
    {
      name: "Poverty & Economic Mobility Dataset",
      description:
        "Compares poverty rates, social mobility, opportunity ratios, and intergenerational mobility metrics.",
      size: "10.2 MB",
      format: "CSV / JSON",
      link: "#",
    },
  ];

  const [selected, setSelected] = useState<number | null>(null);

  return (
    <div style={{ padding: "30px" }}>
      <h2>Datasets</h2>
      <p style={{ marginBottom: "20px" }}>
        Explore downloadable datasets used across the Equal World platform.
      </p>

      <div
        style={{
          background: "#fff",
          padding: "25px",
          borderRadius: "14px",
          boxShadow: "0 0 12px rgba(0,0,0,0.08)",
        }}
      >
        <h3>Available Datasets</h3>

        <div style={{ marginTop: "20px", display: "flex", flexDirection: "column", gap: "20px" }}>
          {datasets.map((d, index) => (
            <div
              key={index}
              style={{
                padding: "18px",
                borderRadius: "12px",
                border: "1px solid #eee",
                background: "#fafafa",
                transition: "0.2s",
                cursor: "pointer",
              }}
              onClick={() => setSelected(index)}
              onMouseEnter={(e) =>
                (e.currentTarget.style.background = "#f2f2f2")
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.background = "#fafafa")
              }
            >
              <h4 style={{ marginBottom: "6px" }}>{d.name}</h4>
              <p style={{ color: "#555", fontSize: "14px" }}>{d.description}</p>

              {selected === index && (
                <div
                  style={{
                    marginTop: "12px",
                    padding: "15px",
                    background: "#fff",
                    borderRadius: "10px",
                    boxShadow: "0 0 8px rgba(0,0,0,0.05)",
                  }}
                >
                  <p>
                    <strong>Size:</strong> {d.size}
                  </p>
                  <p>
                    <strong>Format:</strong> {d.format}
                  </p>

                  <button
                    style={{
                      marginTop: "10px",
                      padding: "10px 16px",
                      borderRadius: "8px",
                      border: "none",
                      background: "#4F46E5",
                      color: "white",
                      cursor: "pointer",
                      fontSize: "14px",
                    }}
                    onClick={() => alert("Download link not set yet")}
                  >
                    Download Dataset
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
