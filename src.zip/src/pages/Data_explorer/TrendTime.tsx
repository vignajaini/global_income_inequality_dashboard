import { useState, useEffect } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Select, SelectTrigger, SelectContent, SelectItem } from "@/components/ui/select";

// ============================
// 🔥 Demo API (Replace Later)
// ============================
import sampleData from "./sample_trend_data.json";
// sampleData structure:
// {
//   "India": { "Gini Index": [...], "GDP per Capita": [...], ... },
//   "China": { "Gini Index": [...], ... }
// }

export default function TrendTimeAnalysis() {
  const countries = Object.keys(sampleData);

  // ============================
  // 🔥 STATE
  // ============================
  const [selectedCountry, setSelectedCountry] = useState("India");
  const [selectedMetric, setSelectedMetric] = useState("Gini Index");
  const [yearRange, setYearRange] = useState([1990, 2020]);

  const metricOptions = Object.keys(sampleData[selectedCountry]);

  const filteredData = sampleData[selectedCountry][selectedMetric].filter(
    (item: any) => item.year >= yearRange[0] && item.year <= yearRange[1]
  );

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-6">
      
      {/* PAGE TITLE */}
      <h1 className="text-3xl font-bold mb-4">Trend & Time Analysis</h1>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">

        {/* ============================ */}
        {/* 🔧 FILTER PANEL */}
        {/* ============================ */}
        <Card className="lg:col-span-1 p-4 glass border">
          <CardHeader>
            <CardTitle className="text-lg">Filters</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">

            {/* COUNTRY SELECT */}
            <div>
              <p className="font-semibold mb-1">Select Country</p>
              <Select value={selectedCountry} onValueChange={setSelectedCountry}>
                <SelectTrigger className="border rounded-md p-2">
                  {selectedCountry}
                </SelectTrigger>
                <SelectContent>
                  {countries.map((c) => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* METRIC SELECT */}
            <div>
              <p className="font-semibold mb-1">Select Metric</p>
              <Select value={selectedMetric} onValueChange={setSelectedMetric}>
                <SelectTrigger className="border rounded-md p-2">
                  {selectedMetric}
                </SelectTrigger>
                <SelectContent>
                  {metricOptions.map((m) => (
                    <SelectItem key={m} value={m}>{m}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* YEAR RANGE SLIDER */}
            <div className="space-y-3">
              <p className="font-semibold">Year Range</p>
              <Slider
                min={1990}
                max={2022}
                step={1}
                value={yearRange}
                onValueChange={setYearRange}
              />
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>{yearRange[0]}</span>
                <span>{yearRange[1]}</span>
              </div>
            </div>

          </CardContent>
        </Card>

        {/* ============================ */}
        {/* 📈 TREND CHART */}
        {/* ============================ */}
        <Card className="lg:col-span-3 p-4 glass border">
          <CardHeader>
            <CardTitle className="text-lg">
              {selectedMetric} — {selectedCountry}
            </CardTitle>
          </CardHeader>

          <CardContent>
            {filteredData.length > 0 ? (
              <div className="w-full h-[420px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={filteredData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#ccc" />
                    <XAxis dataKey="year" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip />
                    <Legend />

                    {/* LINE SERIES */}
                    <Line
                      type="monotone"
                      dataKey="value"
                      stroke="#4f46e5"
                      strokeWidth={3}
                      dot={{ r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <p className="text-center text-gray-500 py-12">
                No data available for this selection.
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
