export default function Publications() {
  const publications = [
    {
      title: "Global Inequality: Trends and Patterns (2024)",
      authors: "Equal World Research Group",
      description:
        "A comprehensive analysis of income inequality trends across 160 countries from 1990 to 2023.",
      link: "#",
    },
    {
      title: "Economic Mobility Barriers in Developing Nations",
      authors: "Dr. A. Mehra, Prof. D. Lewis",
      description:
        "Examines the structural barriers to social mobility and suggests evidence-based policy actions.",
      link: "#",
    },
    {
      title: "Wealth Distribution & Tax Policy Effectiveness",
      authors: "Global Equity Council",
      description:
        "Evaluates how tax reforms impact wealth inequality and middle-class expansion.",
      link: "#",
    },
  ];

  return (
    <div style={{ padding: "30px" }}>
      <h2>Publications</h2>
      <p style={{ marginBottom: "20px" }}>
        Explore research articles, reports, and policy papers published by the Equal World team.
      </p>

      <div
        style={{
          background: "#fff",
          padding: "25px",
          borderRadius: "14px",
          boxShadow: "0 0 12px rgba(0,0,0,0.08)",
        }}
      >
        <h3>Latest Research Papers</h3>

        <div style={{ marginTop: "20px", display: "flex", flexDirection: "column", gap: "20px" }}>
          {publications.map((p, index) => (
            <div
              key={index}
              style={{
                padding: "18px",
                borderRadius: "12px",
                border: "1px solid #eee",
                background: "#fafafa",
                transition: "0.2s",
              }}
              onMouseEnter={(e) => (e.currentTarget.style.background = "#f2f2f2")}
              onMouseLeave={(e) => (e.currentTarget.style.background = "#fafafa")}
            >
              <h4>{p.title}</h4>
              <p style={{ margin: "6px 0", color: "#555" }}>
                <strong>Authors: </strong>
                {p.authors}
              </p>
              <p style={{ color: "#666" }}>{p.description}</p>

              <button
                style={{
                  marginTop: "10px",
                  padding: "9px 14px",
                  background: "#4F46E5",
                  color: "white",
                  borderRadius: "8px",
                  border: "none",
                  cursor: "pointer",
                }}
                onClick={() => alert("PDF link not added yet")}
              >
                View Publication
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
