import React, { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  LineChart,
  Line,
  CartesianGrid,
} from "recharts";

/**
 * OpportunityCalculator.tsx
 * Advanced opportunity calculator (mock model + interactive UI)
 *
 * Drop into: src/pages/Insights/OpportunityCalculator.tsx
 *
 * No external libs required besides recharts (already used elsewhere).
 */

/* ----------------------
   Types
------------------------*/
type CountryCode = "IND" | "USA" | "CHN" | "BRA";
type PercentilePoint = { percentile: number; baselineScore: number; scenarioScore?: number };
type Scenario = {
  name: string;
  educationInvestment: number; // 0..1
  jobProgramIntensity: number; // 0..1
  cashTransferPerc: number; // 0..1 of poverty line
  progressiveTax: number; // 0..0.5
  years: number;
};

/* ----------------------
   Mock data generator
   (Replace with real API eventually)
------------------------*/
function generateBaselineDistribution(country: CountryCode): PercentilePoint[] {
  // baseline opportunity scores per percentile (0..100), lower for poorer countries
  const baseShift = country === "IND" ? -15 : country === "CHN" ? -10 : country === "BRA" ? -12 : -5;
  const arr: PercentilePoint[] = [];
  for (let p = 10; p <= 100; p += 10) {
    // baseline score shaped by percentile (poorer percentiles have lower score)
    const score = Math.max(5, Math.min(95, 50 + (p - 50) * 0.7 + baseShift + Math.sin(p / 10) * 3));
    arr.push({ percentile: p, baselineScore: +score.toFixed(1) });
  }
  return arr;
}

/* ----------------------
   Simulation model
   - returns projected series (years) and final percentile scores
------------------------*/
function runScenario(
  baseline: PercentilePoint[],
  scenario: Scenario
): { timeSeries: { year: number; avgOpportunity: number }[]; finalDistribution: PercentilePoint[] } {
  // Heuristic weights — can be tuned
  const eduEffectiveness = 0.35; // education has big long-run effect
  const jobEffectiveness = 0.30; // job programs medium-term
  const cashEffectiveness = 0.2; // immediate lift for poorest
  const taxRedistributionEffect = 0.15; // helps reduce inequality

  // Convert percentiles to array of numbers
  const baseScores = baseline.map((b) => b.baselineScore);

  // We'll project year-by-year; each year improvements are fractions of full effect depending on intensity.
  const years = scenario.years;
  const series: { year: number; avgOpportunity: number }[] = [];
  let currentScores = [...baseScores];

  for (let y = 1; y <= years; y++) {
    const yearFactor = y / years; // later years closer to full effect

    // Education: benefits accumulate more for middle percentiles (long-run)
    const eduBoost = scenario.educationInvestment * eduEffectiveness * yearFactor;
    // Job programs: best for lower-middle percentiles
    const jobBoost = scenario.jobProgramIntensity * jobEffectiveness * (0.8 * (1 - Math.exp(-y / 3)));
    // Cash transfers: immediate, concentrated at poorest percentiles
    const cashBoost = scenario.cashTransferPerc * cashEffectiveness * (1 - Math.exp(-y / 1.2));
    // Progressive tax: redistributive effect reduces right-tail advantage
    const taxBoost = scenario.progressiveTax * taxRedistributionEffect * yearFactor;

    // Apply to each percentile index (0=10th, 9=100th)
    const newScores = currentScores.map((s, idx) => {
      const pct = (idx + 1) * 10;
      // shaping functions:
      const povertyMultiplier = Math.max(0.4, 1 - (pct / 100)); // poorer percentiles get more from cash
      const eduMultiplier = 0.5 + (pct / 100) * 0.8; // education favors higher percentiles slightly (access), but invest lifts mid-range
      const jobMultiplier = 1 - Math.abs(50 - pct) / 60; // best at lower-mid percentiles
      const taxMultiplier = 1 - (pct / 100) * 0.6; // redistribution helps poorer more

      // incremental boosts
      const delta =
        eduBoost * eduMultiplier * 10 +
        jobBoost * jobMultiplier * 8 +
        cashBoost * povertyMultiplier * 12 +
        taxBoost * taxMultiplier * 6;

      // damping to avoid >100
      return Math.max(0, Math.min(100, s + delta));
    });

    currentScores = newScores;
    const avgOpportunity = currentScores.reduce((a, b) => a + b, 0) / currentScores.length;
    series.push({ year: y, avgOpportunity: +avgOpportunity.toFixed(2) });
  }

  // final distribution mapping back to PercentilePoint[]
  const finalDistribution = baseline.map((b, idx) => ({
    percentile: b.percentile,
    baselineScore: b.baselineScore,
    scenarioScore: +currentScores[idx].toFixed(1),
  }));

  return { timeSeries: series, finalDistribution };
}

/* ----------------------
   Helper: download JSON
------------------------*/
function downloadJSON(filename: string, data: any) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

/* ----------------------
   Component
------------------------*/
export default function OpportunityCalculator(): JSX.Element {
  // UI state
  const [country, setCountry] = useState<CountryCode>("IND");
  const [years, setYears] = useState<number>(10);

  // policy levers (0..1)
  const [educationInvestment, setEducationInvestment] = useState<number>(0.3);
  const [jobProgramIntensity, setJobProgramIntensity] = useState<number>(0.25);
  const [cashTransferPerc, setCashTransferPerc] = useState<number>(0.15);
  const [progressiveTax, setProgressiveTax] = useState<number>(0.12);

  const baseline = useMemo(() => generateBaselineDistribution(country), [country]);

  const scenario: Scenario = {
    name: "User Scenario",
    educationInvestment,
    jobProgramIntensity,
    cashTransferPerc,
    progressiveTax,
    years,
  };

  const { timeSeries, finalDistribution } = useMemo(() => runScenario(baseline, scenario), [
    baseline,
    educationInvestment,
    jobProgramIntensity,
    cashTransferPerc,
    progressiveTax,
    years,
  ]);

  const avgBaseline = useMemo(
    () => +(baseline.reduce((s, b) => s + b.baselineScore, 0) / baseline.length).toFixed(2),
    [baseline]
  );
  const avgScenario = useMemo(
    () =>
      +(
        finalDistribution.reduce((s, b) => s + (b.scenarioScore ?? b.baselineScore), 0) /
        finalDistribution.length
      ).toFixed(2),
    [finalDistribution]
  );

  // simple differential metrics
  const improvement = +(avgScenario - avgBaseline).toFixed(2);
  const improvementPct = +(improvement / (avgBaseline || 1) * 100).toFixed(1);

  // prepare data for charts
  const barChartData = finalDistribution.map((d) => ({
    percentile: `${d.percentile}th`,
    Baseline: d.baselineScore,
    Scenario: d.scenarioScore ?? d.baselineScore,
  }));

  const avgSeriesForChart = timeSeries.map((t) => ({ year: t.year, avgOpportunity: t.avgOpportunity }));

  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-4">Opportunity Calculator — Advanced Simulator</h1>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-6">
        {/* Controls */}
        <div className="lg:col-span-1 bg-white p-4 rounded shadow">
          <label className="block text-sm font-medium mb-2">Country</label>
          <select
            className="w-full p-2 border rounded mb-4"
            value={country}
            onChange={(e) => setCountry(e.target.value as CountryCode)}
          >
            <option value="IND">India</option>
            <option value="CHN">China</option>
            <option value="BRA">Brazil</option>
            <option value="USA">United States</option>
          </select>

          <label className="block text-sm font-medium mb-2">Projection horizon (years)</label>
          <select
            className="w-full p-2 border rounded mb-4"
            value={years}
            onChange={(e) => setYears(Number(e.target.value))}
          >
            <option value={5}>5 years</option>
            <option value={10}>10 years</option>
            <option value={15}>15 years</option>
          </select>

          <div className="text-sm text-gray-600 mb-2">Education investment (0–100%)</div>
          <input
            type="range"
            min={0}
            max={1}
            step={0.01}
            value={educationInvestment}
            onChange={(e) => setEducationInvestment(parseFloat(e.target.value))}
            className="w-full mb-2"
          />
          <div className="text-xs text-muted-foreground mb-4">{Math.round(educationInvestment * 100)}%</div>

          <div className="text-sm text-gray-600 mb-2">Job program intensity (0–100%)</div>
          <input
            type="range"
            min={0}
            max={1}
            step={0.01}
            value={jobProgramIntensity}
            onChange={(e) => setJobProgramIntensity(parseFloat(e.target.value))}
            className="w-full mb-2"
          />
          <div className="text-xs text-muted-foreground mb-4">{Math.round(jobProgramIntensity * 100)}%</div>

          <div className="text-sm text-gray-600 mb-2">Cash transfer (% of poverty line)</div>
          <input
            type="range"
            min={0}
            max={0.5}
            step={0.01}
            value={cashTransferPerc}
            onChange={(e) => setCashTransferPerc(parseFloat(e.target.value))}
            className="w-full mb-2"
          />
          <div className="text-xs text-muted-foreground mb-4">{Math.round(cashTransferPerc * 100)}%</div>

          <div className="text-sm text-gray-600 mb-2">Progressive tax strength</div>
          <input
            type="range"
            min={0}
            max={0.5}
            step={0.01}
            value={progressiveTax}
            onChange={(e) => setProgressiveTax(parseFloat(e.target.value))}
            className="w-full mb-2"
          />
          <div className="text-xs text-muted-foreground mb-4">{Math.round(progressiveTax * 100)}%</div>

          <div className="flex gap-2 mt-4">
            <button
              className="px-3 py-2 bg-blue-600 text-white rounded"
              onClick={() => downloadJSON("opportunity_scenario.json", { country, scenario, finalDistribution })}
            >
              Download scenario JSON
            </button>
            <button
              className="px-3 py-2 bg-gray-200 rounded"
              onClick={() => {
                navigator.clipboard?.writeText(JSON.stringify({ country, scenario, finalDistribution }));
                alert("Scenario JSON copied to clipboard (first 2k chars).");
              }}
            >
              Copy JSON
            </button>
          </div>
        </div>

        {/* KPIs */}
        <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded shadow">
            <div className="text-sm text-muted-foreground">Avg Opportunity (Baseline)</div>
            <div className="text-2xl font-bold">{avgBaseline}</div>
            <div className="text-xs text-muted-foreground">mean across percentiles</div>
          </div>

          <div className="bg-white p-4 rounded shadow">
            <div className="text-sm text-muted-foreground">Avg Opportunity (Scenario)</div>
            <div className="text-2xl font-bold">{avgScenario}</div>
            <div className="text-xs text-muted-foreground">after {years} years</div>
          </div>

          <div className="bg-white p-4 rounded shadow">
            <div className="text-sm text-muted-foreground">Improvement</div>
            <div className="text-2xl font-bold">
              {improvement} ({improvementPct}%)
            </div>
            <div className="text-xs text-muted-foreground">relative to baseline</div>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Bar: percentile distribution */}
        <div className="bg-white p-4 rounded shadow">
          <h3 className="text-lg font-semibold mb-3">Percentile Opportunity — Baseline vs Scenario</h3>
          <div style={{ height: 360 }}>
            <ResponsiveContainer>
              <BarChart data={barChartData} margin={{ top: 10, right: 20, left: 0, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="percentile" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="Baseline" fill="#94a3b8" />
                <Bar dataKey="Scenario" fill="#2563eb" />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="text-sm text-muted-foreground mt-3">
            Each bar shows the opportunity score for the given income percentile (10th → 100th).
          </div>
        </div>

        {/* Line: avg opportunity over time */}
        <div className="bg-white p-4 rounded shadow">
          <h3 className="text-lg font-semibold mb-3">Average Opportunity — Projection</h3>
          <div style={{ height: 360 }}>
            <ResponsiveContainer>
              <LineChart data={avgSeriesForChart}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="avgOpportunity" stroke="#2563eb" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="text-sm text-muted-foreground mt-3">
            The line shows the mean opportunity across percentiles across projection years under the chosen scenario.
          </div>
        </div>
      </div>

      {/* Details & interpretation */}
      <div className="mt-6 bg-white p-4 rounded shadow">
        <h4 className="font-semibold mb-2">Model explanation & interpretation</h4>
        <ul className="list-disc pl-5 text-sm text-muted-foreground">
          <li>The model is intentionally heuristic and meant for scenario prototyping — replace with empirical microdata for production forecasts.</li>
          <li>Education and job programs accumulate benefits over time; cash transfers provide immediate relief to poorest percentiles.</li>
          <li>Progressive taxation supports redistribution that reduces inequality and helps lift lower percentiles.</li>
          <li>To validate results, compare with household survey microdata and run counterfactuals on a backend service.</li>
        </ul>
      </div>
    </div>
  );
}
