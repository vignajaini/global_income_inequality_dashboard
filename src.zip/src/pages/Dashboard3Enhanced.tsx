import { useRef } from "react";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import Chatbot from "@/components/Chatbot";            // ✅ FIXED
import { ZoomableImage } from "@/components/ZoomableImage";
import { toast } from "sonner";
import { generateDashboardPDF } from "@/utils/pdfGenerator";
import { ArrowLeft, Download } from "lucide-react";
import dashboard3 from "@/assets/dashboard3.jpg";

const Dashboard3 = () => {
  const imageRef = useRef<HTMLImageElement>(null);

  const insights = [
    "Education levels strongly correlate with income inequality...",
    "Countries with higher literacy rates show lower inequality...",
    "Regional differences highlight development gaps...",
  ];

  return (
    <div className="min-h-screen gradient-bg">
      <Navbar />
      <Chatbot /> {/* 🎉 FIXED */}

      <div className="pt-24 pb-20 px-4 container mx-auto max-w-6xl">
        <Link to="/home">
          <Button variant="ghost" className="mb-6">
            <ArrowLeft size={18} className="mr-2" /> Back to Home
          </Button>
        </Link>

        <div className="animate-fade-in">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Inequality & Education Analysis
            </span>
          </h1>

          {/* Chart */}
          <ZoomableImage src={dashboard3} alt="Education Dashboard" />
          <img ref={imageRef} src={dashboard3} alt="hidden" className="hidden" />

          {/* Insights */}
          <div className="glass rounded-xl p-6 mt-8">
            <h2 className="text-2xl font-bold mb-4">Key Findings</h2>
            {insights.map((t, i) => (
              <p key={i} className="p-3 mb-2 bg-muted/50 rounded-lg">
                {i + 1}. {t}
              </p>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard3;
