import { useEffect, useRef, useState } from "react";
import * as d3 from "d3";
import { feature } from "topojson-client";

type Topology = {
  objects: {
    countries: any;
  };
};

export default function GlobalHeatmap() {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const [hoverCountry, setHoverCountry] = useState<string | null>(null);
  const [hoverValue, setHoverValue] = useState<number | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    async function drawMap() {
      try {
        const worldUrl =
          "https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json";

        const topoJson: Topology = await d3.json(worldUrl);
        const geoData = feature(topoJson, topoJson.objects.countries);

        const svg = d3.select(svgRef.current);
        svg.selectAll("*").remove();

        const width = 850;
        const height = 500;

        const projection = d3.geoMercator().fitSize([width, height], geoData);
        const path = d3.geoPath().projection(projection);

        const color = d3.scaleSequential(d3.interpolateYlOrRd).domain([0, 100]);

        svg
          .selectAll("path")
          .data(geoData.features)
          .enter()
          .append("path")
          .attr("d", path as any)
          .attr("fill", () => color(Math.random() * 100))
          .attr("stroke", "#ccc")
          .attr("strokeWidth", 0.6)
          .on("mouseenter", (event: any, d: any) => {
            const randomValue = Math.floor(Math.random() * 100);
            setHoverCountry(
              d.properties.name || 
              d.properties.NAME || 
              d.properties.ADMIN || 
              "Unknown"
            );
            setHoverValue(randomValue);
          })
          .on("mouseleave", () => {
            setHoverCountry(null);
            setHoverValue(null);
          });

      } catch (err) {
        console.error("Error loading map:", err);
        setError("Failed to load world map data.");
      }
    }

    drawMap();
  }, []);

  return (
    <div style={{ padding: "25px", display: "flex", gap: "25px" }}>
      
      {/* LEFT PANEL — MAP */}
      <div
        style={{
          flex: 3,
          background: "#fff",
          padding: "20px",
          borderRadius: "14px",
          boxShadow: "0 0 12px rgba(0,0,0,0.08)",
        }}
      >
        {/* ⭐ BIGGER TITLE HERE */}
        <h2
          style={{
            fontSize: "28px",
            fontWeight: 700,
            marginBottom: "10px",
            color: "#222",
          }}
        >
          Global Inequality Heatmap
        </h2>

        {error && <p style={{ color: "red" }}>{error}</p>}

        <svg
          ref={svgRef}
          width={850}
          height={500}
          style={{
            background: "#f9f9f9",
            borderRadius: "12px",
            marginTop: "15px",
          }}
        />

        {/* COLOR LEGEND */}
        <div style={{ marginTop: "25px" }}>
          <h4 style={{ fontWeight: 600, marginBottom: "8px" }}>Heatmap Legend</h4>

          <div
            style={{
              height: "20px",
              width: "300px",
              background:
                "linear-gradient(to right, #ffffcc, #ffeda0, #feb24c, #f03b20)",
              borderRadius: "6px",
            }}
          />

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              width: "300px",
              marginTop: "6px",
              fontSize: "13px",
              color: "#444",
            }}
          >
            <small>Low Inequality</small>
            <small>High Inequality</small>
          </div>
        </div>
      </div>

      {/* RIGHT PANEL — INSIGHTS */}
      <div
        style={{
          flex: 1,
          background: "#fff",
          padding: "20px",
          borderRadius: "14px",
          boxShadow: "0 0 12px rgba(0,0,0,0.08)",
          maxHeight: "550px",
          overflowY: "auto",
        }}
      >
        <h3 style={{ fontSize: "22px", fontWeight: 600 }}>Country Insights</h3>

        {!hoverCountry && (
          <p style={{ marginTop: "10px", color: "#777" }}>
            Hover over any country to see inequality details.
          </p>
        )}

        {hoverCountry && (
          <div
            style={{
              marginTop: "15px",
              padding: "15px",
              background: "#f6f6f6",
              borderRadius: "10px",
            }}
          >
            <h4
              style={{
                fontSize: "18px",
                fontWeight: 600,
                marginBottom: "4px",
              }}
            >
              {hoverCountry}
            </h4>

            <p style={{ fontSize: "15px" }}>
              Inequality Score: <strong>{hoverValue}</strong>
            </p>

            <p style={{ fontSize: "13px", marginTop: "6px", color: "#666" }}>
              This value represents simulated inequality for demo purposes.
            </p>
          </div>
        )}

        <div style={{ marginTop: "25px" }}>
          <h4 style={{ fontWeight: 600, marginBottom: "8px" }}>
            Global Insights
          </h4>

          <p style={{ color: "#555", fontSize: "14px", lineHeight: "1.6" }}>
            Heatmaps visually reveal global inequality patterns.  
            Darker regions represent higher inequality.
          </p>

          <ul style={{ marginTop: "10px", lineHeight: "1.6", fontSize: "14px" }}>
            <li>Sub-Saharan Africa shows higher inequality.</li>
            <li>Europe and Oceania generally show lower inequality.</li>
            <li>Asia has mixed inequality levels across regions.</li>
            <li>
              Use this heatmap to compare inequality across continents.
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
