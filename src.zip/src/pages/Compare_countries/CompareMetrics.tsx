import React, { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  BarChart,
  Bar,
} from "recharts";

/**
 * CompareMetrics.tsx
 * A self-contained compare page with dummy data (two-country comparison),
 * dropdown filters, KPI cards, and a responsive Recharts visualization.
 *
 * Place this file at: src/pages/Compare_countries/CompareMetrics.tsx
 *
 * NOTE: this uses Tailwind utility classes (your project appears to have Tailwind).
 * If you don't have Tailwind, either add basic CSS or replace classes with inline styles.
 */

type YearDatum = {
  year: string;
  a: number;
  b: number;
};

const DUMMY_PAIRS = [
  { id: "in_cn", label: "India vs China", a: "India", b: "China" },
  { id: "us_uk", label: "US vs UK", a: "United States", b: "United Kingdom" },
  { id: "br_sa", label: "Brazil vs South Africa", a: "Brazil", b: "South Africa" },
];

const INDICATORS = [
  { id: "gini", label: "Gini Index", unit: "" },
  { id: "palma", label: "Palma Ratio", unit: "" },
  { id: "gdp", label: "GDP per Capita (USD)", unit: "USD" },
];

/** Create dummy time series for each pair+indicator */
function makeDummySeries(pairId: string, indicatorId: string): YearDatum[] {
  // Shared year range
  const years = Array.from({ length: 14 }, (_, i) => 2010 + i).map(String);

  // base seeds, vary by pair & indicator so charts look different
  const baseSeed =
    (pairId === "in_cn" ? 1 : pairId === "us_uk" ? 2 : 3) +
    (indicatorId === "gini" ? 0 : indicatorId === "palma" ? 0.5 : 3);

  return years.map((y, idx) => {
    // create two series with smooth variation
    const a = Math.round((baseSeed + Math.sin(idx / 2) * 0.7 + idx * 0.12) * (indicatorId === "gdp" ? 1000 : 1) * (1 + (pairId === "in_cn" ? 0.5 : 0)));
    const b = Math.round((baseSeed + Math.cos(idx / 3) * 0.6 + idx * 0.08) * (indicatorId === "gdp" ? 950 : 1) * (1 + (pairId === "in_cn" ? 0.55 : 0.1)));
    return { year: y, a, b };
  });
}

export default function CompareMetrics(): JSX.Element {
  const [pair, setPair] = useState(DUMMY_PAIRS[0].id);
  const [indicator, setIndicator] = useState(INDICATORS[0].id);
  const [chartType, setChartType] = useState<"line" | "bar">("line");

  const pairMeta = DUMMY_PAIRS.find((p) => p.id === pair)!;
  const indicatorMeta = INDICATORS.find((i) => i.id === indicator)!;

  // Memoize series
  const series = useMemo(() => makeDummySeries(pair, indicator), [pair, indicator]);

  // quick KPIs (simple averages) - formatted
  const kpiA = useMemo(() => {
    const avg = Math.round(series.reduce((s, r) => s + r.a, 0) / series.length);
    return avg;
  }, [series]);

  const kpiB = useMemo(() => {
    const avg = Math.round(series.reduce((s, r) => s + r.b, 0) / series.length);
    return avg;
  }, [series]);

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-2xl font-semibold mb-4">Compare Gini, Palma, GDP</h1>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-6">
        {/* MAIN PANEL */}
        <div>
          <div className="bg-white shadow rounded-lg p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-lg font-medium">Side-by-Side Comparison</h2>
                <p className="text-sm text-muted-foreground mt-1">
                  Compare <strong>{pairMeta.a}</strong> and <strong>{pairMeta.b}</strong> by{" "}
                  <strong>{indicatorMeta.label}</strong>
                </p>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex gap-2">
                  <button
                    onClick={() => setChartType("line")}
                    className={`px-3 py-1 rounded ${chartType === "line" ? "bg-primary text-white" : "bg-gray-100"}`}
                  >
                    Line
                  </button>
                  <button
                    onClick={() => setChartType("bar")}
                    className={`px-3 py-1 rounded ${chartType === "bar" ? "bg-primary text-white" : "bg-gray-100"}`}
                  >
                    Bars
                  </button>
                </div>
              </div>
            </div>

            {/* KPI Row */}
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="p-3 bg-gray-50 rounded">
                <div className="text-sm text-muted-foreground">Average ({pairMeta.a})</div>
                <div className="text-xl font-semibold">{kpiA.toLocaleString()} {indicatorMeta.unit}</div>
              </div>
              <div className="p-3 bg-gray-50 rounded">
                <div className="text-sm text-muted-foreground">Average ({pairMeta.b})</div>
                <div className="text-xl font-semibold">{kpiB.toLocaleString()} {indicatorMeta.unit}</div>
              </div>
            </div>

            {/* Chart area */}
            <div style={{ height: 320 }} className="rounded-lg overflow-hidden bg-gray-100 p-4">
              <ResponsiveContainer width="100%" height="100%">
                {chartType === "line" ? (
                  <LineChart data={series}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="year" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="a" name={pairMeta.a} stroke="#1f77b4" strokeWidth={2} dot={false} />
                    <Line type="monotone" dataKey="b" name={pairMeta.b} stroke="#ff7f0e" strokeWidth={2} dot={false} />
                  </LineChart>
                ) : (
                  <BarChart data={series}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="year" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="a" name={pairMeta.a} fill="#1f77b4" />
                    <Bar dataKey="b" name={pairMeta.b} fill="#ff7f0e" />
                  </BarChart>
                )}
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* RIGHT SIDEBAR */}
        <aside>
          <div className="bg-white shadow rounded-lg p-5 space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Select Countries</label>
              <select
                value={pair}
                onChange={(e) => setPair(e.target.value)}
                className="w-full rounded border px-3 py-2"
              >
                {DUMMY_PAIRS.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Select Indicator</label>
              <select
                value={indicator}
                onChange={(e) => setIndicator(e.target.value)}
                className="w-full rounded border px-3 py-2"
              >
                {INDICATORS.map((i) => (
                  <option key={i.id} value={i.id}>
                    {i.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <h4 className="text-sm font-medium mb-2">Selected:</h4>
              <div className="text-sm text-foreground/80">
                <div>{DUMMY_PAIRS.find((p) => p.id === pair)!.label}</div>
                <div>{INDICATORS.find((i) => i.id === indicator)!.label}</div>
              </div>
            </div>

            <div className="pt-2 border-t">
              <button
                onClick={() => {
                  // lightweight demo: toggle chart type quickly
                  setChartType((s) => (s === "line" ? "bar" : "line"));
                }}
                className="w-full px-4 py-2 rounded bg-primary text-white"
              >
                Toggle Chart Type
              </button>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
