import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  Legend,
} from "recharts";

/* ------------------------------------
   TYPES
------------------------------------ */
type MetricKey = "gini" | "palma" | "gdp_per_capita";

type TimePoint = {
  year: number;
  gini: number;
  palma: number;
  gdp_per_capita: number;
};

type CountryData = {
  countryCode: string;
  countryName: string;
  series: TimePoint[];
  latest: {
    year: number;
    gini: number;
    palma: number;
    gdp_per_capita: number;
  };
};

/* ------------------------------------
   MOCK FETCH — Replace later with API call
------------------------------------ */
async function fetchCountryData(countryCode: string): Promise<CountryData> {
  await new Promise((r) => setTimeout(r, 300));

  const years = Array.from({ length: 27 }, (_, i) => 1995 + i);
  const rand = (min: number, max: number) =>
    +(Math.random() * (max - min) + min).toFixed(2);

  const series = years.map((y) => ({
    year: y,
    gini: rand(25, 55),
    palma: rand(0.8, 3.5),
    gdp_per_capita: +rand(1000, 60000),
  }));

  const latest = series[series.length - 1];

  return {
    countryCode,
    countryName:
      countryCode === "IND"
        ? "India"
        : countryCode === "USA"
        ? "United States"
        : countryCode === "CHN"
        ? "China"
        : "Country",
    series,
    latest,
  };
}

/* ------------------------------------
   UI Lists
------------------------------------ */
const COUNTRIES = [
  { code: "IND", label: "India" },
  { code: "USA", label: "United States" },
  { code: "CHN", label: "China" },
  { code: "BRA", label: "Brazil" },
];

const METRICS: { key: MetricKey; label: string }[] = [
  { key: "gini", label: "Gini Index" },
  { key: "palma", label: "Palma Ratio" },
  { key: "gdp_per_capita", label: "GDP per Capita (USD)" },
];

/* ------------------------------------
   COMPONENT
------------------------------------ */
export default function CountryOverview() {
  const [country, setCountry] = useState("IND");
  const [metric, setMetric] = useState<MetricKey>("gini");
  const [range, setRange] = useState<[number, number]>([1995, 2021]);

  /* FIXED — React Query WITH TYPE */
  const { data, isLoading, error } = useQuery<CountryData>({
    queryKey: ["country", country],
    queryFn: () => fetchCountryData(country),
    staleTime: 1000 * 60 * 5,
  });

  /* Filter by year range */
  const chartData = useMemo(() => {
    if (!data) return [];
    return data.series.filter(
      (d) => d.year >= range[0] && d.year <= range[1]
    );
  }, [data, range]);

  const metricLabel = METRICS.find((m) => m.key === metric)?.label ?? "-";
  const kpiValue = data
    ? metric === "gdp_per_capita"
      ? data.latest.gdp_per_capita.toLocaleString()
      : (data.latest as any)[metric]
    : "--";

  return (
    <div className="p-6">
      <h2 className="text-2xl font-semibold mb-4">Country Overview</h2>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* LEFT PANEL */}
        <div className="bg-white p-4 rounded shadow">
          <label className="font-medium">Select Country</label>
          <select
            value={country}
            onChange={(e) => setCountry(e.target.value)}
            className="w-full mt-2 mb-4 border px-3 py-2 rounded"
          >
            {COUNTRIES.map((c) => (
              <option key={c.code} value={c.code}>
                {c.label}
              </option>
            ))}
          </select>

          <label className="font-medium">Select Metric</label>
          <select
            value={metric}
            onChange={(e) => setMetric(e.target.value as MetricKey)}
            className="w-full mt-2 mb-4 border px-3 py-2 rounded"
          >
            {METRICS.map((m) => (
              <option key={m.key} value={m.key}>
                {m.label}
              </option>
            ))}
          </select>

          {/* Year Range Slider */}
          <div>
            <label className="font-medium">Year Range</label>
            <div className="flex items-center gap-2 mt-2">
              <span>{range[0]}</span>
              <input
                type="range"
                min={1995}
                max={2021}
                value={range[0]}
                onChange={(e) =>
                  setRange([Number(e.target.value), range[1]])
                }
              />
              <input
                type="range"
                min={1995}
                max={2021}
                value={range[1]}
                onChange={(e) =>
                  setRange([range[0], Number(e.target.value)])
                }
              />
              <span>{range[1]}</span>
            </div>
          </div>
        </div>

        {/* RIGHT PANEL */}
        <div className="col-span-3 space-y-6">
          {/* KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-4 rounded shadow">
              <div className="text-sm text-gray-500">Country</div>
              <div className="text-xl font-semibold">
                {data?.countryName ?? "--"}
              </div>
            </div>

            <div className="bg-white p-4 rounded shadow">
              <div className="text-sm text-gray-500">Metric</div>
              <div className="font-semibold">{metricLabel}</div>
              <div className="text-xl mt-2">{kpiValue}</div>
            </div>

            <div className="bg-white p-4 rounded shadow">
              <div className="text-sm text-gray-500">Change</div>
              <div className="font-semibold">
                {data
                  ? (() => {
                      const start = data.series[0][metric];
                      const end = data.latest[metric];
                      const pct = ((end - start) / start) * 100;
                      return `${pct > 0 ? "+" : ""}${pct.toFixed(1)}%`;
                    })()
                  : "--"}
              </div>
            </div>
          </div>

          {/* Chart */}
          <div className="bg-white p-4 rounded shadow">
            <h3 className="text-lg font-medium mb-4">
              Trend — {metricLabel}
            </h3>

            <div style={{ height: 320 }}>
              {isLoading ? (
                <div className="flex items-center justify-center h-full">
                  Loading...
                </div>
              ) : error ? (
                <div className="text-red-500">Failed to load.</div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="year" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line
                      dataKey={metric}
                      stroke="#2563eb"
                      strokeWidth={2}
                      dot={false}
                      name={metricLabel}
                    />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
