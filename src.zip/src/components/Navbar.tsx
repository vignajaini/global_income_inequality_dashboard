import { Link, NavLink, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { logout, getCurrentUser, isAuthenticated } from "@/lib/auth";
import { BarChart3, LogOut, Menu, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { ThemeToggle } from "./ThemeToggle";

export const Navbar = () => {
  const navigate = useNavigate();
  const user = getCurrentUser();
  const authenticated = isAuthenticated();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const navRef = useRef<HTMLElement | null>(null);

  const toggleDropdown = (name: string) => {
    setOpenDropdown((current) => (current === name ? null : name));
  };

  const closeAll = () => {
    setOpenDropdown(null);
    setMobileMenuOpen(false);
  };

  const handleLogout = () => {
    logout();
    navigate("/");
    closeAll();
  };

  // Close dropdown when clicking outside the navbar
  useEffect(() => {
    function handleDocumentClick(e: MouseEvent) {
      if (!navRef.current) return;
      if (!navRef.current.contains(e.target as Node)) {
        setOpenDropdown(null);
      }
    }
    document.addEventListener("click", handleDocumentClick);
    return () => document.removeEventListener("click", handleDocumentClick);
  }, []);

  // Admin visibility: change condition if you prefer a different rule
  // Show Admin only if user email matches admin email
    const showAdmin = authenticated && user?.email === "admin@gmail.com";


  // Helper to close dropdown + mobile when navigating from a link
  const onNavigate = (cb?: () => void) => {
    setOpenDropdown(null);
    setMobileMenuOpen(false);
    if (cb) cb();
  };

  return (
    <nav
      ref={navRef}
      className="fixed top-0 left-0 right-0 z-50 glass border-b border-border/30"
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">

          {/* LOGO */}
          <Link
            to={authenticated ? "/home" : "/"}
            className="flex items-center gap-2 text-xl font-bold"
            onClick={() => onNavigate()}
          >
            <BarChart3 className="text-primary" size={28} />
            <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Global Insights
            </span>
          </Link>

          {/* DESKTOP MENU */}
          <div className="hidden md:flex items-center gap-6">

            {/* DATA EXPLORER */}
            <div className="relative">
              <span
                className="cursor-pointer hover:text-primary"
                onClick={() => toggleDropdown("data")}
                role="button"
                tabIndex={0}
              >
                Data Explorer ▾
              </span>

              {openDropdown === "data" && (
               <div
                  className="absolute left-0 mt-2 w-56 bg-[#f3f4f6]/80 backdrop-blur border border-border/40
                            rounded-lg shadow-lg p-2 flex flex-col"
                >

                  <NavLink to="/data-explorer/overview" onClick={() => onNavigate()}>
                    Overview Dashboard
                  </NavLink>
                  <NavLink to="/data-explorer/global-heatmap" onClick={() => onNavigate()}>
                    Global Heatmap
                  </NavLink>
                  <NavLink to="/data-explorer/trend-time" onClick={() => onNavigate()}>
                    Trend & Time Analysis
                  </NavLink>
                  <NavLink to="/data-explorer/correlations" onClick={() => onNavigate()}>
                    Variable Correlations
                  </NavLink>
                  <NavLink to="/data-explorer/upload-merge" onClick={() => onNavigate()}>
                    Upload & Merge Data
                  </NavLink>
                </div>
              )}
            </div>

            {/* COUNTRY PROFILES */}
            <div className="relative">
              <span
                className="cursor-pointer hover:text-primary"
                onClick={() => toggleDropdown("country")}
                role="button"
                tabIndex={0}
              >
                Country Profiles ▾
              </span>

              {openDropdown === "country" && (
                <div
                    className="absolute left-0 mt-2 w-56 bg-[#f3f4f6]/80 backdrop-blur border border-border/40
                              rounded-lg shadow-lg p-2 flex flex-col"
                >

                  <NavLink to="/country-profile/overview" onClick={() => onNavigate()}>
                    Country Overview
                  </NavLink>
                  <NavLink to="/country-profile/regional-comparison" onClick={() => onNavigate()}>
                    Regional Comparison
                  </NavLink>
                  <NavLink to="/country-profile/country-trends" onClick={() => onNavigate()}>
                    Country Trends
                  </NavLink>
                  <NavLink to="/country-profile/policy-insights" onClick={() => onNavigate()}>
                    Policy Insights
                  </NavLink>
                </div>
              )}
            </div>

            {/* COMPARE COUNTRIES */}
            <div className="relative">
              <span
                className="cursor-pointer hover:text-primary"
                onClick={() => toggleDropdown("compare")}
                role="button"
                tabIndex={0}
              >
                Compare Countries ▾
              </span>

              {openDropdown === "compare" && (
                <div
                    className="absolute left-0 mt-2 w-56 bg-[#f3f4f6]/80 backdrop-blur border border-border/40
                              rounded-lg shadow-lg p-2 flex flex-col"
                >
                  <NavLink to="/compare-countries/metrics" onClick={() => onNavigate()}>
                    Compare Metrics
                  </NavLink>
                  <NavLink to="/compare-countries/multi-timeline" onClick={() => onNavigate()}>
                    Multi Timeline
                  </NavLink>
                  <NavLink to="/compare-countries/summary" onClick={() => onNavigate()}>
                    Metric Summary
                  </NavLink>
                </div>
              )}
            </div>

            {/* INSIGHTS */}
            <div className="relative">
              <span
                className="cursor-pointer hover:text-primary"
                onClick={() => toggleDropdown("insights")}
                role="button"
                tabIndex={0}
              >
                Insights ▾
              </span>

              {openDropdown === "insights" && (
                <div
                    className="absolute left-0 mt-2 w-56 bg-[#f3f4f6]/80 backdrop-blur border border-border/40
                              rounded-lg shadow-lg p-2 flex flex-col"
                >
                  <NavLink to="/insights/mobility-timeline" onClick={() => onNavigate()}>
                    Mobility Timeline
                  </NavLink>
                  <NavLink to="/insights/opportunity-calculator" onClick={() => onNavigate()}>
                    Opportunity Calculator
                  </NavLink>
                  <NavLink to="/insights/policy-impact" onClick={() => onNavigate()}>
                    Policy Impact Simulator
                  </NavLink>
                  <NavLink to="/insights/factor-breakdown" onClick={() => onNavigate()}>
                    Factor Breakdown
                  </NavLink>
                </div>
              )}
            </div>

            {/* RESEARCH */}
            <div className="relative">
              <span
                className="cursor-pointer hover:text-primary"
                onClick={() => toggleDropdown("research")}
                role="button"
                tabIndex={0}
              >
                Research ▾
              </span>

              {openDropdown === "research" && (
                <div
                    className="absolute left-0 mt-2 w-56 bg-[#f3f4f6]/80 backdrop-blur border border-border/40
                              rounded-lg shadow-lg p-2 flex flex-col"
                >
                  <NavLink to="/research/datasets" onClick={() => onNavigate()}>
                    Datasets
                  </NavLink>
                  <NavLink to="/research/case-studies" onClick={() => onNavigate()}>
                    Case Studies
                  </NavLink>
                  <NavLink to="/research/publications" onClick={() => onNavigate()}>
                    Publications / Reports
                  </NavLink>
                  <NavLink to="/research/data-dictionary" onClick={() => onNavigate()}>
                    Data Dictionary
                  </NavLink>
                </div>
              )}
            </div>

            {/* Right-side links */}
            <NavLink to="/timeline" className="hover:text-primary" onClick={() => onNavigate()}>
              Timeline
            </NavLink>

            <NavLink to="/contact" className="hover:text-primary" onClick={() => onNavigate()}>
              Contact
            </NavLink>

            {/* Admin link (only visible to admin users) */}
            {showAdmin && (
              <NavLink to="/admin" className="hover:text-primary" onClick={() => onNavigate()}>
                Admin
              </NavLink>
            )}

            <ThemeToggle />

            {/* USER INFO + LOGOUT */}
            {authenticated && (
              <div className="flex items-center gap-4">
                <span className="text-sm text-muted-foreground">
                  Welcome, {user?.name || user?.email}
                </span>
                <Button onClick={handleLogout} variant="outline" size="sm">
                  <LogOut size={16} className="mr-2" />
                  Logout
                </Button>
              </div>
            )}
          </div>

          {/* MOBILE MENU TOGGLE */}
          <button
            className="md:hidden text-foreground"
            onClick={() => setMobileMenuOpen((s) => !s)}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* MOBILE MENU */}
      {mobileMenuOpen && (
        <div className="md:hidden glass border-t border-border/30 animate-fade-in">
          <div className="container mx-auto px-4 py-4 flex flex-col gap-3">

            <Link to="/data-explorer/overview" onClick={() => onNavigate()}>
              Data Explorer
            </Link>

            <Link to="/country-profile/overview" onClick={() => onNavigate()}>
              Country Profiles
            </Link>

            <Link to="/compare-countries/metrics" onClick={() => onNavigate()}>
              Compare Countries
            </Link>

            <Link to="/insights/mobility-timeline" onClick={() => onNavigate()}>
              Insights
            </Link>

            <Link to="/research/datasets" onClick={() => onNavigate()}>
              Research
            </Link>

            <Link to="/timeline" onClick={() => onNavigate()}>
              Timeline
            </Link>

            <Link to="/contact" onClick={() => onNavigate()}>
              Contact
            </Link>

            {showAdmin && (
              <Link to="/admin" onClick={() => onNavigate()}>
                Admin
              </Link>
            )}

            {authenticated && (
              <>
                <div className="text-sm text-muted-foreground py-2">
                  Welcome, {user?.name || user?.email}
                </div>
                <Button onClick={handleLogout} variant="outline" size="sm" className="w-full">
                  <LogOut size={16} className="mr-2" />
                  Logout
                </Button>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};
