export default function CaseStudies() {
  const cases = [
    {
      title: "How Brazil Reduced Extreme Poverty (2003–2014)",
      region: "Latin America",
      description:
        "A deep dive into Brazil's Bolsa Família program, tracking its impact on child education and rural mobility.",
      link: "#",
    },
    {
      title: "Rising Inequality in the United States",
      region: "North America",
      description:
        "Analyzes wage stagnation, wealth concentration, and policy gaps influencing widening inequality.",
      link: "#",
    },
    {
      title: "Social Mobility in Scandinavian Countries",
      region: "Europe",
      description:
        "Explores why Norway, Sweden, and Denmark consistently score highest in mobility and equal opportunity.",
      link: "#",
    },
  ];

  return (
    <div style={{ padding: "30px" }}>
      <h2>Case Studies</h2>
      <p style={{ marginBottom: "20px" }}>
        Explore real-world examples showcasing policy outcomes, inequality patterns, and mobility solutions.
      </p>

      <div
        style={{
          background: "#fff",
          padding: "25px",
          borderRadius: "14px",
          boxShadow: "0 0 12px rgba(0,0,0,0.08)",
        }}
      >
        <h3>Featured Case Studies</h3>

        <div style={{ marginTop: "20px", display: "flex", flexDirection: "column", gap: "20px" }}>
          {cases.map((c, index) => (
            <div
              key={index}
              style={{
                padding: "18px",
                borderRadius: "12px",
                border: "1px solid #eee",
                background: "#fafafa",
                transition: "0.2s",
              }}
              onMouseEnter={(e) => (e.currentTarget.style.background = "#f2f2f2")}
              onMouseLeave={(e) => (e.currentTarget.style.background = "#fafafa")}
            >
              <h4>{c.title}</h4>
              <p style={{ fontSize: "14px", color: "#777" }}>
                <strong>Region:</strong> {c.region}
              </p>
              <p style={{ color: "#555" }}>{c.description}</p>

              <button
                style={{
                  marginTop: "10px",
                  padding: "9px 14px",
                  background: "#4F46E5",
                  color: "white",
                  borderRadius: "8px",
                  border: "none",
                  cursor: "pointer",
                }}
                onClick={() => alert("Case study not available yet")}
              >
                View Full Study
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
