import { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  BarChart,
  Bar,
} from "recharts";

/**
 * PolicyInsights.tsx
 * Advanced interactive policy simulator for a single country's inequality metrics.
 *
 * Drop into: src/pages/Country_profile/PolicyInsights.tsx
 *
 * Notes:
 * - This uses mock data and a simple simulation formula (illustrative).
 * - Replace mockFetch / simulation logic with real backend/empirical model later.
 */

/* --------------------------
   Types
   -------------------------- */
type YearPoint = {
  year: number;
  gini: number;
  gdp: number;
  poverty: number;
};

type PolicyScenario = {
  name: string;
  taxRate: number; // progressive tax strength 0..1
  transferPerc: number; // % of collected tax that is redistributed to poorest
};

/* --------------------------
   Mock / Data
   -------------------------- */
function mockFetchHistorical(countryCode = "IND"): YearPoint[] {
  // 2009..2024
  const startYear = 2009;
  const baseGini = 36;
  const baseGDP = 2200;
  const basePoverty = 22;

  return Array.from({ length: 16 }, (_, i) => {
    const year = startYear + i;
    // slight noisey trend
    const gini = +(baseGini + (Math.sin(i / 3) * 1.5) + i * 0.05).toFixed(2);
    const gdp = +(baseGDP + i * 400 + Math.cos(i / 2) * 30).toFixed(0);
    const poverty = +(basePoverty - i * 0.4 + Math.sin(i / 2) * 0.6).toFixed(2);
    return { year, gini, gdp, poverty };
  });
}

/* --------------------------
   Simulation Model (simple)
   - policy taxRate reduces Gini proportional to taxRate * effectiveness
   - transferPerc increases poverty reduction effectiveness
   - We also apply multiplier effects across future years
   -------------------------- */
function simulatePolicy(
  history: YearPoint[],
  policy: PolicyScenario,
  yearsToProject = 10
): YearPoint[] {
  // small heuristic parameters
  const baseEffectiveness = 0.9; // how effective tax->inequality reduction is
  const transferBoost = policy.transferPerc; // proportion useful
  const shockDampening = 0.98; // small damping across years

  // last historic point
  const last = history[history.length - 1];
  const proj: YearPoint[] = [];

  let currentGini = last.gini;
  let currentGDP = last.gdp;
  let currentPoverty = last.poverty;

  for (let t = 1; t <= yearsToProject; t++) {
    const year = last.year + t;

    // simulate GDP growth slightly improved by progressive transfers (small effect)
    const gdpGrowthFactor = 1 + 0.02 + policy.taxRate * 0.01 * (0.5 + transferBoost);
    currentGDP = +(currentGDP * gdpGrowthFactor).toFixed(0);

    // inequality reduction: proportional to taxRate * baseEffectiveness * transferBoost
    // also scale by diminishing returns across years
    const yearlyReduction =
      policy.taxRate * baseEffectiveness * (0.3 + transferBoost * 0.7) * Math.pow(shockDampening, t - 1);

    // but ensure we don't go negative
    currentGini = +(Math.max(18, currentGini - yearlyReduction).toFixed(2));

    // poverty responds to transfers and GDP growth
    const povertyDrop =
      0.4 * transferBoost * policy.taxRate * 10 + (gdpGrowthFactor - 1) * 2; // heuristic
    currentPoverty = +(Math.max(0, currentPoverty - povertyDrop).toFixed(2));

    proj.push({ year, gini: currentGini, gdp: currentGDP, poverty: currentPoverty });
  }

  return proj;
}

/* --------------------------
   Component
   -------------------------- */
export default function PolicyInsights() {
  const history = useMemo(() => mockFetchHistorical("IND"), []);
  const [taxRate, setTaxRate] = useState(0.15); // 15% progressive strength
  const [transferPerc, setTransferPerc] = useState(0.6); // 60% of tax redistributed
  const [yearsToProject, setYearsToProject] = useState(10);

  const scenario: PolicyScenario = {
    name: "User Scenario",
    taxRate,
    transferPerc,
  };

  const projection = useMemo(
    () => simulatePolicy(history, scenario, yearsToProject),
    [history, taxRate, transferPerc, yearsToProject]
  );

  // Merge history + projected for combined chart
  const combined = [
    ...history.map((h) => ({ ...h, type: "history" })),
    ...projection.map((p) => ({ ...p, type: "projection" })),
  ];

  const beforeGini = history[history.length - 1].gini;
  const afterGini = projection[projection.length - 1].gini;
  const giniDelta = +(afterGini - beforeGini).toFixed(2);

  return (
    <div className="p-6">
      <h2 className="text-2xl font-semibold mb-4">Policy Insights — Simulation Studio</h2>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Controls */}
        <div className="col-span-1 lg:col-span-2 bg-white p-5 rounded shadow">
          <h3 className="font-medium mb-2">Policy Controls</h3>

          <div className="mb-4">
            <label className="block text-sm text-muted-foreground mb-1">Progressive Tax Strength</label>
            <input
              type="range"
              min={0}
              max={0.5}
              step={0.01}
              value={taxRate}
              onChange={(e) => setTaxRate(parseFloat(e.target.value))}
              aria-label="taxRate"
            />
            <div className="text-sm mt-1">{Math.round(taxRate * 100)}% tax strength</div>
          </div>

          <div className="mb-4">
            <label className="block text-sm text-muted-foreground mb-1">Redistribution to Poorest</label>
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={transferPerc}
              onChange={(e) => setTransferPerc(parseFloat(e.target.value))}
              aria-label="transferPerc"
            />
            <div className="text-sm mt-1">{Math.round(transferPerc * 100)}% of collected tax redistributed</div>
          </div>

          <div className="flex gap-4 items-center">
            <div>
              <label className="block text-sm text-muted-foreground mb-1">Years to project</label>
              <select
                value={yearsToProject}
                onChange={(e) => setYearsToProject(parseInt(e.target.value))}
                className="p-2 border rounded"
              >
                <option value={5}>5 years</option>
                <option value={10}>10 years</option>
                <option value={15}>15 years</option>
              </select>
            </div>

            <div className="ml-auto text-right">
              <div className="text-sm text-muted-foreground">Projected Gini change</div>
              <div className="text-xl font-bold">
                {giniDelta < 0 ? (
                  <span className="text-green-600">↓ {Math.abs(giniDelta)}</span>
                ) : (
                  <span className="text-red-600">+{giniDelta}</span>
                )}
              </div>
              <div className="text-xs text-muted-foreground">(lower is better)</div>
            </div>
          </div>
        </div>

        {/* KPIs */}
        <div className="bg-white p-5 rounded shadow">
          <h4 className="font-medium mb-3">Quick KPIs</h4>

          <div className="space-y-3">
            <div>
              <div className="text-sm text-muted-foreground">Current Gini</div>
              <div className="text-lg font-bold">{beforeGini}</div>
            </div>

            <div>
              <div className="text-sm text-muted-foreground">Projected Gini ({projection[projection.length - 1].year})</div>
              <div className="text-lg font-bold">{afterGini}</div>
            </div>

            <div>
              <div className="text-sm text-muted-foreground">Projected Poverty</div>
              <div className="text-lg font-bold">{projection[projection.length - 1].poverty}%</div>
            </div>

            <div>
              <div className="text-sm text-muted-foreground">Projected GDP per cap</div>
              <div className="text-lg font-bold">${projection[projection.length - 1].gdp}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Charts area */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Gini line: history + projection */}
        <div className="bg-white p-4 rounded shadow">
          <h4 className="font-semibold mb-3">Gini — History & Projection</h4>
          <div style={{ height: 340 }}>
            <ResponsiveContainer>
              <LineChart data={combined}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis domain={["dataMin - 2", "dataMax + 2"]} />
                <Tooltip />
                <Legend />
                <Line
                  name="Gini (history)"
                  dataKey="gini"
                  stroke="#2563eb"
                  strokeWidth={2}
                  dot={{ r: 2 }}
                  isAnimationActive={false}
                  // Only show solid for history; we will style projection differently
                  strokeDasharray={undefined}
                />
                {/* Projection overlay: we'll render the same key but dashed where type==='projection' */}
                {/* Recharts renders series by key; we simply show one line. Projection is contiguous. */}
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="text-sm text-muted-foreground mt-2">
            Blue line shows past values and projected future under the current policy assumptions.
          </div>
        </div>

        {/* Before/After Bar & Poverty */}
        <div className="bg-white p-4 rounded shadow">
          <h4 className="font-semibold mb-3">Before / After Comparison</h4>

          <div style={{ height: 300 }}>
            <ResponsiveContainer>
              <BarChart
                data={[
                  { label: "Before", gini: beforeGini, poverty: history[history.length - 1].poverty },
                  { label: "After", gini: afterGini, poverty: projection[projection.length - 1].poverty },
                ]}
                layout="vertical"
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis dataKey="label" type="category" />
                <Tooltip />
                <Legend />
                <Bar dataKey="gini" name="Gini" fill="#2563eb" />
                <Bar dataKey="poverty" name="Poverty (%)" fill="#f97316" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="text-sm text-muted-foreground mt-2">
            Bars compare the last historical year vs final projected year for Gini and Poverty.
          </div>
        </div>
      </div>

      {/* Explain panel */}
      <div className="bg-white p-4 rounded shadow mt-6">
        <h4 className="font-semibold mb-2">How this model works</h4>
        <ul className="list-disc pl-5 text-sm text-muted-foreground">
          <li>
            Progressive tax strength increases the share of resources available for redistribution;
            stronger tax strength → higher simulated Gini reduction.
          </li>
          <li>
            Transfer efficiency (redistribution %) controls how much of collected revenue goes to poorest households.
          </li>
          <li>
            The model is intentionally simple — use it to prototype scenarios; integrate empirical microdata or a public finance model for production-grade projections.
          </li>
        </ul>
      </div>
    </div>
  );
}
