import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
} from "recharts";

/* ======================================================
   TYPES
====================================================== */
type MetricKey = "gini" | "palma" | "gdp_per_capita";

type CountryStats = {
  countryName: string;
  gini: number;
  palma: number;
  gdp_per_capita: number;
};

type RegionData = {
  countries: CountryStats[];
};

/* ======================================================
   MOCK API (Replace with backend)
====================================================== */
async function fetchRegionComparison(
  selected: string[]
): Promise<RegionData> {
  await new Promise((r) => setTimeout(r, 300));

  const rand = (min: number, max: number) =>
    +(Math.random() * (max - min) + min).toFixed(2);

  const data: Record<string, string> = {
    IND: "India",
    USA: "United States",
    CHN: "China",
    BRA: "Brazil",
    ZAF: "South Africa",
    MEX: "Mexico",
  };

  return {
    countries: selected.map((code) => ({
      countryName: data[code],
      gini: rand(25, 55),
      palma: rand(0.8, 3.5),
      gdp_per_capita: rand(1500, 60000),
    })),
  };
}

/* ======================================================
   OPTIONS
====================================================== */
const ALL_COUNTRIES = [
  { code: "IND", label: "India" },
  { code: "USA", label: "United States" },
  { code: "CHN", label: "China" },
  { code: "BRA", label: "Brazil" },
  { code: "ZAF", label: "South Africa" },
  { code: "MEX", label: "Mexico" },
];

const METRICS: { key: MetricKey; label: string }[] = [
  { key: "gini", label: "Gini Index" },
  { key: "palma", label: "Palma Ratio" },
  { key: "gdp_per_capita", label: "GDP Per Capita (USD)" },
];

/* ======================================================
   COMPONENT
====================================================== */
export default function RegionalComparison() {
  const [selectedCountries, setSelectedCountries] = useState<string[]>([
    "IND",
    "CHN",
    "USA",
  ]);
  const [metric, setMetric] = useState<MetricKey>("gini");

  const { data, isLoading, error } = useQuery<RegionData>({
    queryKey: ["region-compare", selectedCountries],
    queryFn: () => fetchRegionComparison(selectedCountries),
    staleTime: 1000 * 60 * 5,
  });

  /* Transform for Radar Chart */
  const radarData = METRICS.map((m) => ({
    metric: m.label,
    ...Object.fromEntries(
      data?.countries.map((c) => [
        c.countryName,
        c[m.key as keyof CountryStats],
      ]) ?? []
    ),
  }));

  const barData = data?.countries || [];

  return (
    <div className="p-6">
      <h2 className="text-2xl font-semibold mb-6">
        Regional Comparison — Advanced View
      </h2>

      {/* =========================== 
          FILTER PANEL 
      ============================ */}
      <div className="bg-white p-4 rounded shadow mb-6 grid grid-cols-1 md:grid-cols-2 gap-6">

        {/* Country Multi-Select */}
        <div>
          <label className="font-medium">Select Countries</label>
          <select
            multiple
            className="w-full border p-3 rounded mt-2 h-40"
            value={selectedCountries}
            onChange={(e) => {
              const options = Array.from(e.target.selectedOptions);
              setSelectedCountries(options.map((o) => o.value));
            }}
          >
            {ALL_COUNTRIES.map((c) => (
              <option key={c.code} value={c.code}>
                {c.label}
              </option>
            ))}
          </select>
          <p className="text-sm text-gray-500 mt-1">
            Hold CTRL to select multiple.
          </p>
        </div>

        {/* Metric Selector */}
        <div>
          <label className="font-medium">Compare Metric</label>
          <select
            className="w-full border p-3 rounded mt-2"
            value={metric}
            onChange={(e) => setMetric(e.target.value as MetricKey)}
          >
            {METRICS.map((m) => (
              <option key={m.key} value={m.key}>
                {m.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* =========================== 
          KPI Cards
      ============================ */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        {data?.countries.map((c) => (
          <div
            key={c.countryName}
            className="bg-white p-4 shadow rounded border"
          >
            <div className="text-gray-500 text-sm">{c.countryName}</div>
            <div className="text-xl font-semibold mt-2">
              {metric === "gdp_per_capita"
                ? c.gdp_per_capita.toLocaleString()
                : c[metric]}
            </div>
            <div className="text-gray-400 text-sm mt-1">
              {METRICS.find((m) => m.key === metric)?.label}
            </div>
          </div>
        ))}
      </div>

      {/* =========================== 
          BAR CHART (Single Metric)
      ============================ */}
      <div className="bg-white p-4 rounded shadow mb-6">
        <h3 className="text-lg font-semibold mb-4">
          {METRICS.find((m) => m.key === metric)?.label} Comparison
        </h3>

        <div style={{ width: "100%", height: 350 }}>
          {isLoading ? (
            <div className="flex items-center justify-center h-full">
              Loading...
            </div>
          ) : error ? (
            <div className="text-red-500">Failed to load data.</div>
          ) : (
            <ResponsiveContainer>
              <BarChart data={barData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="countryName" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar
                  dataKey={metric}
                  fill="#2563eb"
                  name={METRICS.find((m) => m.key === metric)?.label}
                />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* =========================== 
          RADAR CHART (All Metrics)
      ============================ */}
      <div className="bg-white p-4 rounded shadow">
        <h3 className="text-lg font-semibold mb-4">Full Metric Radar Comparison</h3>

        <div style={{ width: "100%", height: 400 }}>
          {isLoading ? (
            <div className="flex items-center justify-center h-full">
              Loading...
            </div>
          ) : (
            <ResponsiveContainer>
              <RadarChart cx="50%" cy="50%" outerRadius="70%" data={radarData}>
                <PolarGrid />
                <PolarAngleAxis dataKey="metric" />
                <PolarRadiusAxis />
                {data?.countries.map((c, idx) => (
                  <Radar
                    key={c.countryName}
                    name={c.countryName}
                    dataKey={c.countryName}
                    stroke={["#2563eb", "#16a34a", "#dc2626", "#9333ea"][idx % 4]}
                    fill={["#2563eb55", "#16a34a55", "#dc262655", "#9333ea55"][idx % 4]}
                    fillOpacity={0.6}
                  />
                ))}
                <Legend />
              </RadarChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>
    </div>
  );
}
