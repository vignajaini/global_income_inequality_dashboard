import { useRef } from "react";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { ArrowLeft, TrendingUp, Activity, LineChart, Layers, Download } from "lucide-react";
import { Link } from "react-router-dom";
import { ZoomableImage } from "@/components/ZoomableImage";
import Chatbot from "@/components/Chatbot";              // ✅ FIXED
import { generateDashboardPDF } from "@/utils/pdfGenerator";
import { toast } from "sonner";
import dashboard2 from "@/assets/dashboard2.jpg";

const Dashboard2 = () => {
  const imageRef = useRef<HTMLImageElement>(null);

  const insights = [
    "Total income steadily increased from 2000-2023...",
    "Top 10% income share consistently dominates...",
    "Ribbon chart shows shifting inequality rankings...",
  ];

  return (
    <div className="min-h-screen gradient-bg">
      <Navbar />
      <Chatbot />   {/* ❤️ Working */}

      <div className="pt-24 pb-20 px-4 container mx-auto max-w-6xl">
        <Link to="/home">
          <Button variant="ghost" className="mb-6">
            <ArrowLeft size={18} className="mr-2" /> Back to Home
          </Button>
        </Link>

        <div className="animate-fade-in">
          {/* Title */}
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-4xl md:text-5xl font-bold">
              <span className="bg-gradient-to-r from-secondary to-accent bg-clip-text text-transparent">
                Inequality Trends Over Time
              </span>
            </h1>
          </div>

          {/* Dashboard Image */}
          <ZoomableImage src={dashboard2} alt="Trends Dashboard" />
          <img ref={imageRef} src={dashboard2} alt="hidden" className="hidden" />

          {/* Insights */}
          <div className="glass rounded-xl p-6 mt-8">
            <h2 className="text-2xl font-bold mb-4">Key Insights</h2>
            {insights.map((text, index) => (
              <p key={index} className="p-3 mb-2 bg-muted/50 rounded-lg">
                {index + 1}. {text}
              </p>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard2;
