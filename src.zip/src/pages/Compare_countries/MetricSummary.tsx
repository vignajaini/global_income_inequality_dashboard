import React, { useMemo } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
} from "recharts";

/**
 * MetricSummary.tsx
 * Displays summary KPIs, ranks, and mini trend-lines for two countries.
 */

const COUNTRY_PAIRS = [
  { id: "in_cn", a: "India", b: "China", label: "India vs China" },
  { id: "us_uk", a: "United States", b: "United Kingdom", label: "US vs UK" },
  { id: "br_sa", a: "Brazil", b: "South Africa", label: "Brazil vs South Africa" },
];

const INDICATORS = [
  { id: "gini", label: "Gini Index", better: "lower" },
  { id: "palma", label: "Palma Ratio", better: "lower" },
  { id: "gdp", label: "GDP per Capita", better: "higher" },
];

// Dummy trend generator
function trendData(seed: number) {
  return Array.from({ length: 8 }, (_, i) => ({
    idx: i,
    val: Math.round(seed + Math.sin(i / 2) * 3 + i * 1.2),
  }));
}

export default function MetricSummary(): JSX.Element {
  // Default pair (India vs China)
  const pair = COUNTRY_PAIRS[0];

  // Dummy KPI values
  const kpis = useMemo(() => ({
    gini: {
      a: 35,
      b: 30,
      trendA: trendData(32),
      trendB: trendData(28),
    },
    palma: {
      a: 1.2,
      b: 1.05,
      trendA: trendData(1.1 * 20),
      trendB: trendData(0.98 * 20),
    },
    gdp: {
      a: 2200,
      b: 9000,
      trendA: trendData(2100 / 50),
      trendB: trendData(8500 / 50),
    },
  }), []);

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-2xl font-semibold mb-4">Metric Summary</h1>
      <p className="text-muted-foreground mb-6">
        Quick comparison overview between <strong>{pair.a}</strong> and{" "}
        <strong>{pair.b}</strong>.
      </p>

      {/* KPI GRID */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {INDICATORS.map((ind) => {
          const item = kpis[ind.id as keyof typeof kpis];

          return (
            <div key={ind.id} className="bg-white rounded-lg shadow p-5">
              <h2 className="text-lg font-medium mb-2">{ind.label}</h2>

              {/* KPI VALUES */}
              <div className="flex justify-between items-center mb-3">
                <div>
                  <div className="text-sm text-muted-foreground">{pair.a}</div>
                  <div className="text-xl font-semibold">{item.a}</div>
                </div>

                <div>
                  <div className="text-sm text-muted-foreground">{pair.b}</div>
                  <div className="text-xl font-semibold">{item.b}</div>
                </div>
              </div>

              {/* RANK INDICATOR */}
              <div className="mb-3">
                {ind.better === "lower" ? (
                  item.a < item.b ? (
                    <span className="text-green-600 text-sm font-medium">
                      ✓ {pair.a} performs better
                    </span>
                  ) : (
                    <span className="text-blue-600 text-sm font-medium">
                      ✓ {pair.b} performs better
                    </span>
                  )
                ) : (
                  item.a > item.b ? (
                    <span className="text-green-600 text-sm font-medium">
                      ✓ {pair.a} performs better
                    </span>
                  ) : (
                    <span className="text-blue-600 text-sm font-medium">
                      ✓ {pair.b} performs better
                    </span>
                  )
                )}
              </div>

              {/* MINI TREND CHART */}
              <div style={{ height: 80 }} className="bg-gray-50 rounded p-1">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={item.trendA}>
                    <Line
                      type="monotone"
                      dataKey="val"
                      stroke="#1f77b4"
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          );
        })}
      </div>

      {/* SUMMARY CARD */}
      <div className="bg-white rounded-lg shadow p-6 mt-8">
        <h2 className="text-lg font-semibold mb-3">Summary Insights</h2>

        <ul className="space-y-2 text-sm leading-relaxed">
          <li>
            • <strong>{pair.b}</strong> shows stronger GDP growth, indicating higher economic stability.
          </li>
          <li>
            • <strong>{pair.a}</strong> has improved its poverty-related indicators in the last decade.
          </li>
          <li>
            • Both countries show gradual improvement in Palma Ratio.
          </li>
          <li>
            • Strong convergence trend in inequality indices between both countries.
          </li>
        </ul>
      </div>
    </div>
  );
}
